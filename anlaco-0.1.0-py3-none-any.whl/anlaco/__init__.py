"""Anlaco: un lenguaje de programación que se lee como un libro."""

__version__ = "0.1.0"
