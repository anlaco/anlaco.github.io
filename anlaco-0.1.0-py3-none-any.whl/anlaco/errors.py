"""Errores de Anlaco.

El mensaje de error es parte del lenguaje (espec §8): cada idioma tiene su
tabla en mensajes/XX.toml, igual que las palabras clave. Los módulos no llevan
frases escritas: piden un mensaje por su clave ("parser.falta_fin") y el idioma
del programa decide cómo suena.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

MENSAJES_DIR = Path(__file__).parent / "mensajes"

_tablas: dict[str, dict] = {}


def _tabla(idioma: str) -> dict:
    if idioma not in _tablas:
        ruta = MENSAJES_DIR / f"{idioma}.toml"
        if not ruta.exists():
            ruta = MENSAJES_DIR / "es.toml"  # el español es la tabla de reserva
        _tablas[idioma] = tomllib.loads(ruta.read_text("utf-8"))
    return _tablas[idioma]


def mensaje(idioma: str, clave: str, **datos) -> str:
    seccion, nombre = clave.split(".")
    plantilla = _tabla(idioma)[seccion][nombre]
    return plantilla.format(**datos)


class ErrorDeAnlaco(Exception):
    def __init__(self, texto: str, linea: int | None = None, idioma: str = "es"):
        self.mensaje = texto
        self.linea = linea
        self.idioma = idioma
        if linea:
            prefijo = mensaje(idioma, "general.error_con_linea", linea=linea)
        else:
            prefijo = mensaje(idioma, "general.error")
        super().__init__(f"{prefijo} {texto}")


def error(idioma: str, clave: str, linea: int | None = None, **datos) -> ErrorDeAnlaco:
    return ErrorDeAnlaco(mensaje(idioma, clave, **datos), linea, idioma)
