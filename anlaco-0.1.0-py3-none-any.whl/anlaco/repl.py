"""REPL de Anlaco: la sesión interactiva.

Escribes una frase y se ejecuta al momento; las variables y funciones se
recuerdan durante toda la sesión. Un bloque (si, para cada, define...) se
sigue leyendo línea a línea hasta que sus "fin" lo cierran.
"""

from __future__ import annotations

import sys
from typing import Callable, TextIO

from . import ast_nodes as ast
from .errors import ErrorDeAnlaco, mensaje
from .interpreter import Interprete
from .lexer import frases_de_idioma
from .parser import parse
from .tokens import TokenType


def iniciar(idioma: str = "es", leer: Callable[[str], str] | None = None,
            salida: TextIO | None = None, entrada: TextIO | None = None) -> None:
    """Arranca la sesión. `leer` y `salida` se pueden sustituir en los tests."""
    salida = salida or sys.stdout
    if leer is None:
        try:
            import readline  # noqa: F401  (historial con las flechas)
        except ImportError:
            pass
        leer = input

    frases = frases_de_idioma(idioma)
    palabra_fin = frases[TokenType.KW_END][0]          # fin / end
    frase_si_no = frases[TokenType.KW_ELSE][0]         # si no / otherwise
    palabra_salir = mensaje(idioma, "repl.salir")

    interprete = Interprete(entrada=entrada, salida=salida, idioma=idioma)
    salida.write(mensaje(idioma, "repl.bienvenida") + "\n")

    pendientes: list[str] = []
    abiertos = 0
    while True:
        try:
            linea = leer("... " if pendientes else ">>> ")
        except EOFError:
            salida.write("\n" + mensaje(idioma, "repl.adios") + "\n")
            return

        limpia = linea.strip()
        if not pendientes:
            if limpia == palabra_salir:
                salida.write(mensaje(idioma, "repl.adios") + "\n")
                return
            if limpia == "":
                continue

        pendientes.append(linea)
        if limpia.endswith(":") and not limpia.startswith(frase_si_no):
            abiertos += 1
        elif limpia == palabra_fin:
            abiertos -= 1

        if abiertos > 0:
            continue

        fragmento = "\n".join(pendientes)
        pendientes = []
        abiertos = 0
        try:
            programa = parse(fragmento, idioma)
            for sentencia in programa.sentencias:
                if isinstance(sentencia, ast.Define):
                    interprete.funciones[sentencia.nombre] = sentencia
            for sentencia in programa.sentencias:
                if not isinstance(sentencia, ast.Define):
                    interprete.sentencia(sentencia, interprete.globales)
        except ErrorDeAnlaco as error:
            salida.write(error.mensaje + "\n")
