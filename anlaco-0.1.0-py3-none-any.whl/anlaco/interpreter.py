"""Intérprete de Anlaco: recorre el árbol del programa y lo ejecuta.

Es un intérprete "tree-walking": el primer backend del árbol. El día de mañana
los compiladores del futuro serán más backends del MISMO árbol; por eso la semántica
está definida en espec/especificacion.md §6 y no en lo que Python haga por azar.

Cubre el lenguaje v0.1 completo. Habla el idioma del programa: los errores y
los literales (verdadero/true, nada/nothing) salen de mensajes/XX.toml.
"""

from __future__ import annotations

import random
import re
import sys
from pathlib import Path
from typing import TextIO

from . import ast_nodes as ast
from .errors import error, mensaje

_RE_ENTERO = re.compile(r"-?\d+$")
_RE_DECIMAL = re.compile(r"-?\d+\.\d+$")

MAXIMO_DE_LLAMADAS = 1000  # profundidad garantizada por la especificación §6


class Entorno:
    """Las variables visibles: las locales de la función, o las del programa.

    Desde una función se pueden LEER las variables del programa, pero asignar
    siempre crea o cambia una local (espec §6).
    """

    def __init__(self, idioma: str = "es", globales: dict | None = None):
        self.idioma = idioma
        self.variables: dict[str, object] = {}
        self.globales = globales  # None si ESTE entorno es el global

    def obtener(self, nombre: str, linea: int):
        if nombre in self.variables:
            return self.variables[nombre]
        if self.globales is not None and nombre in self.globales:
            return self.globales[nombre]
        raise error(self.idioma, "interprete.no_existe", linea, nombre=nombre)

    def poner(self, nombre: str, valor: object):
        self.variables[nombre] = valor


class _Devolver(Exception):
    """Control interno: transporta el valor de un "devuelve" hasta la llamada."""

    def __init__(self, valor):
        self.valor = valor


class Interprete:
    def __init__(self, entrada: TextIO | None = None, salida: TextIO | None = None,
                 idioma: str = "es"):
        self.entrada = entrada or sys.stdin
        self.salida = salida or sys.stdout
        self.idioma = idioma
        self.globales = Entorno(idioma)
        self.funciones: dict[str, ast.Define] = {}
        self.profundidad = 0

    def mostrar(self, valor) -> str:
        return mostrar(valor, self.idioma)

    def _error(self, clave: str, linea: int, **datos):
        return error(self.idioma, clave, linea, **datos)

    # --- puesta en marcha ---

    def ejecutar(self, programa: ast.Programa):
        # el intérprete anida varios marcos de Python por cada llamada de Anlaco
        sys.setrecursionlimit(max(sys.getrecursionlimit(), MAXIMO_DE_LLAMADAS * 20))
        for sentencia in programa.sentencias:
            if isinstance(sentencia, ast.Define):
                self.funciones[sentencia.nombre] = sentencia
        for sentencia in programa.sentencias:
            if not isinstance(sentencia, ast.Define):
                self.sentencia(sentencia, self.globales)

    # --- sentencias ---

    def sentencia(self, nodo: ast.Nodo, entorno: Entorno):
        if isinstance(nodo, ast.Escribe):
            self.salida.write(self.mostrar(self.evaluar(nodo.expresion, entorno)) + "\n")
        elif isinstance(nodo, ast.Asigna):
            entorno.poner(nodo.nombre, self.evaluar(nodo.expresion, entorno))
        elif isinstance(nodo, ast.Si):
            if self.condicion(nodo.condicion, entorno):
                self.bloque(nodo.entonces, entorno)
            elif nodo.sino is not None:
                self.bloque(nodo.sino, entorno)
        elif isinstance(nodo, ast.ParaCadaEnLista):
            lista = self.evaluar(nodo.lista, entorno)
            self._exigir_lista(lista, nodo.lista.linea)
            for elemento in lista:
                entorno.poner(nodo.variable, elemento)
                self.bloque(nodo.cuerpo, entorno)
        elif isinstance(nodo, ast.ParaCadaEnRango):
            desde = self._exigir_entero(self.evaluar(nodo.desde, entorno), nodo.linea)
            hasta = self._exigir_entero(self.evaluar(nodo.hasta, entorno), nodo.linea)
            for numero in range(desde, hasta + 1):
                entorno.poner(nodo.variable, numero)
                self.bloque(nodo.cuerpo, entorno)
        elif isinstance(nodo, ast.Repite):
            veces = self._exigir_entero(self.evaluar(nodo.veces, entorno), nodo.linea)
            for _ in range(veces):
                self.bloque(nodo.cuerpo, entorno)
        elif isinstance(nodo, ast.Mientras):
            while self.condicion(nodo.condicion, entorno):
                self.bloque(nodo.cuerpo, entorno)
        elif isinstance(nodo, ast.Devuelve):
            valor = None if nodo.expresion is None else self.evaluar(nodo.expresion, entorno)
            if entorno.globales is None:
                raise self._error("interprete.devuelve_fuera", nodo.linea)
            raise _Devolver(valor)
        elif isinstance(nodo, ast.Guarda):
            valor = self.evaluar(nodo.valor, entorno)
            ruta = self._exigir_texto(self.evaluar(nodo.ruta, entorno), nodo.linea)
            Path(ruta).write_text(self.mostrar(valor), "utf-8")
        elif isinstance(nodo, ast.Anade):
            self._anadir(nodo, entorno)
        elif isinstance(nodo, ast.Llamada):
            self.llamar(nodo, entorno)
        else:  # no debería pasar: el parser solo produce sentencias conocidas
            raise self._error("parser.inicio_desconocido", nodo.linea)

    def bloque(self, sentencias: list[ast.Nodo], entorno: Entorno):
        for sentencia in sentencias:
            self.sentencia(sentencia, entorno)

    def condicion(self, nodo: ast.Nodo, entorno: Entorno) -> bool:
        valor = self.evaluar(nodo, entorno)
        if not isinstance(valor, bool):
            raise self._error("interprete.condicion_booleana", nodo.linea,
                              valor=self.mostrar(valor))
        return valor

    def _anadir(self, nodo: ast.Anade, entorno: Entorno):
        valor = self.evaluar(nodo.valor, entorno)
        destino = self.evaluar(nodo.destino, entorno)
        if isinstance(destino, list):
            destino.append(valor)
        elif isinstance(destino, str):
            ruta = Path(destino)
            anterior = ruta.read_text("utf-8") if ruta.exists() else ""
            ruta.write_text(anterior + self.mostrar(valor), "utf-8")
        else:
            raise self._error("interprete.anade_destino", nodo.linea,
                              valor=self.mostrar(destino))

    # --- expresiones ---

    def evaluar(self, nodo: ast.Nodo, entorno: Entorno):
        if isinstance(nodo, ast.Numero):
            return nodo.valor
        if isinstance(nodo, ast.Booleano):
            return nodo.valor
        if isinstance(nodo, ast.Nada):
            return None
        if isinstance(nodo, ast.Nombre):
            return self._nombre(nodo, entorno)
        if isinstance(nodo, ast.Texto):
            trozos = []
            for parte in nodo.partes:
                if isinstance(parte, str):
                    trozos.append(parte)
                else:
                    trozos.append(self.mostrar(self.evaluar(parte, entorno)))
            return "".join(trozos)
        if isinstance(nodo, ast.Lista):
            return [self.evaluar(elemento, entorno) for elemento in nodo.elementos]
        if isinstance(nodo, ast.MenosUnario):
            valor = self.evaluar(nodo.expresion, entorno)
            self._exigir_numero(valor, nodo.linea)
            return -valor
        if isinstance(nodo, ast.Binaria):
            return self.binaria(nodo, entorno)
        if isinstance(nodo, ast.Llamada):
            return self.llamar(nodo, entorno)
        if isinstance(nodo, ast.RespuestaA):
            return self._preguntar(nodo, entorno)
        if isinstance(nodo, ast.ElementoDe):
            lista = self.evaluar(nodo.coleccion, entorno)
            self._exigir_lista(lista, nodo.linea)
            indice = self._exigir_entero(self.evaluar(nodo.indice, entorno), nodo.linea)
            if not 1 <= indice <= len(lista):
                raise self._error("interprete.indice_fuera", nodo.linea,
                                  cantidad=len(lista), indice=indice)
            return lista[indice - 1]
        if isinstance(nodo, ast.PrimeroDe):
            return self._extremo(nodo, entorno, primero=True)
        if isinstance(nodo, ast.UltimoDe):
            return self._extremo(nodo, entorno, primero=False)
        if isinstance(nodo, ast.CantidadDe):
            lista = self.evaluar(nodo.coleccion, entorno)
            self._exigir_lista(lista, nodo.linea)
            return len(lista)
        if isinstance(nodo, ast.ContenidoDe):
            ruta = self._exigir_texto(self.evaluar(nodo.ruta, entorno), nodo.linea)
            if not Path(ruta).exists():
                raise self._error("interprete.archivo_no_encontrado", nodo.linea, ruta=ruta)
            return Path(ruta).read_text("utf-8")
        if isinstance(nodo, ast.AlAzarEntre):
            desde = self._exigir_entero(self.evaluar(nodo.desde, entorno), nodo.linea)
            hasta = self._exigir_entero(self.evaluar(nodo.hasta, entorno), nodo.linea)
            if desde > hasta:
                raise self._error("interprete.azar_orden", nodo.linea, desde=desde, hasta=hasta)
            return random.randint(desde, hasta)
        raise self._error("parser.valor_esperado", nodo.linea)

    def binaria(self, nodo: ast.Binaria, entorno: Entorno):
        operador = nodo.operador

        if operador in ("and", "or"):
            izquierda = self.condicion(nodo.izquierda, entorno)
            if operador == "and" and not izquierda:
                return False
            if operador == "or" and izquierda:
                return True
            return self.condicion(nodo.derecha, entorno)

        izquierda = self.evaluar(nodo.izquierda, entorno)
        derecha = self.evaluar(nodo.derecha, entorno)

        if operador == "==":
            return son_iguales(izquierda, derecha)
        if operador == "!=":
            return not son_iguales(izquierda, derecha)

        if operador in (">", "<", ">=", "<="):
            self._exigir_numero(izquierda, nodo.linea)
            self._exigir_numero(derecha, nodo.linea)
            return {
                ">": izquierda > derecha,
                "<": izquierda < derecha,
                ">=": izquierda >= derecha,
                "<=": izquierda <= derecha,
            }[operador]

        # matemáticas: + - * /
        self._exigir_numero(izquierda, nodo.linea)
        self._exigir_numero(derecha, nodo.linea)
        if operador == "+":
            return izquierda + derecha
        if operador == "-":
            return izquierda - derecha
        if operador == "*":
            return izquierda * derecha
        if derecha == 0:
            raise self._error("interprete.division_cero", nodo.linea)
        return izquierda / derecha

    # --- funciones ---

    def llamar(self, nodo: ast.Llamada, entorno: Entorno):
        definicion = self.funciones.get(nodo.nombre)
        if definicion is None:
            raise self._error("interprete.funcion_desconocida", nodo.linea, nombre=nodo.nombre)
        if len(nodo.argumentos) != len(definicion.parametros):
            raise self._error(
                "interprete.argumentos", nodo.linea,
                nombre=nodo.nombre,
                espera=len(definicion.parametros),
                parametros=", ".join(definicion.parametros) or "-",
                llegan=len(nodo.argumentos),
            )
        if self.profundidad >= MAXIMO_DE_LLAMADAS:
            raise self._error("interprete.demasiadas_llamadas", nodo.linea,
                              maximo=MAXIMO_DE_LLAMADAS)
        local = Entorno(self.idioma, globales=self.globales.variables)
        for parametro, argumento in zip(definicion.parametros, nodo.argumentos):
            local.poner(parametro, self.evaluar(argumento, entorno))
        self.profundidad += 1
        try:
            self.bloque(definicion.cuerpo, local)
            return None
        except _Devolver as devolver:
            return devolver.valor
        finally:
            self.profundidad -= 1

    def _nombre(self, nodo: ast.Nombre, entorno: Entorno):
        """Un nombre suelto: variable, o función sin parámetros (se llama sola)."""
        try:
            return entorno.obtener(nodo.nombre, nodo.linea)
        except Exception:
            definicion = self.funciones.get(nodo.nombre)
            if definicion is not None and not definicion.parametros:
                return self.llamar(ast.Llamada(nodo.linea, nodo.nombre, []), entorno)
            if definicion is not None:
                raise self._error("interprete.funcion_con_parametros", nodo.linea,
                                  nombre=nodo.nombre) from None
            raise

    # --- entrada del usuario ---

    def _preguntar(self, nodo: ast.RespuestaA, entorno: Entorno):
        pregunta = self.evaluar(nodo.pregunta, entorno)
        self.salida.write(self.mostrar(pregunta) + "\n")
        self.salida.flush()
        linea = self.entrada.readline()
        if linea == "":
            raise self._error("interprete.sin_respuesta", nodo.linea)
        respuesta = linea.rstrip("\n")
        if _RE_ENTERO.match(respuesta):
            return int(respuesta)
        if _RE_DECIMAL.match(respuesta):
            return float(respuesta)
        return respuesta

    # --- ayudas ---

    def _extremo(self, nodo, entorno: Entorno, primero: bool):
        lista = self.evaluar(nodo.coleccion, entorno)
        self._exigir_lista(lista, nodo.linea)
        if not lista:
            clave = "interprete.lista_vacia_primero" if primero else "interprete.lista_vacia_ultimo"
            raise self._error(clave, nodo.linea)
        return lista[0] if primero else lista[-1]

    def _exigir_numero(self, valor, linea: int):
        if isinstance(valor, bool) or not isinstance(valor, (int, float)):
            raise self._error("interprete.numero_esperado", linea, valor=self.mostrar(valor))

    def _exigir_entero(self, valor, linea: int) -> int:
        self._exigir_numero(valor, linea)
        if isinstance(valor, float):
            if not valor.is_integer():
                raise self._error("interprete.entero_esperado", linea, valor=self.mostrar(valor))
            return int(valor)
        return valor

    def _exigir_texto(self, valor, linea: int) -> str:
        if not isinstance(valor, str):
            raise self._error("interprete.texto_esperado", linea, valor=self.mostrar(valor))
        return valor

    def _exigir_lista(self, valor, linea: int):
        if not isinstance(valor, list):
            raise self._error("interprete.lista_esperada", linea, valor=self.mostrar(valor))


def son_iguales(izquierda, derecha) -> bool:
    """Igualdad de Anlaco: tipos distintos dan falso, salvo entero vs decimal."""
    if isinstance(izquierda, bool) != isinstance(derecha, bool):
        return False
    if isinstance(izquierda, (int, float)) and isinstance(derecha, (int, float)):
        return izquierda == derecha
    if type(izquierda) is not type(derecha):
        return False
    return izquierda == derecha


def mostrar(valor, idioma: str = "es") -> str:
    """Cómo se enseña un valor a la persona (espec §6), en el idioma del programa."""
    if valor is None:
        return mensaje(idioma, "literales.nada")
    if isinstance(valor, bool):
        return mensaje(idioma, "literales.verdadero" if valor else "literales.falso")
    if isinstance(valor, float):
        if valor.is_integer():
            return str(int(valor))
        return str(valor)
    if isinstance(valor, list):
        return "[" + ", ".join(mostrar(elemento, idioma) for elemento in valor) + "]"
    return str(valor)
