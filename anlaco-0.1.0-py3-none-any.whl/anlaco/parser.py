"""Parser de Anlaco: convierte las fichas del lexer en el árbol del programa.

Es un parser de descenso recursivo escrito a mano: cada regla de la gramática
(espec/especificacion.md §11) es un método. Implementa las reglas clave:

- la isla de cálculo: los símbolos matemáticos SOLO existen dentro de paréntesis
  (fuera de ellos, un "+" produce el error amable que enseña la forma correcta)
- los argumentos de una llamada son valores cerrados; una llamada con argumentos
  como argumento de otra o como elemento de lista pide sus propios paréntesis
- "es" al inicio de sentencia es asignación; dentro de una condición, igualdad
- la interpolación {…} de los textos se analiza aquí, con el mismo idioma

Los mensajes de error se piden por clave a mensajes/XX.toml (espec §8).
"""

from __future__ import annotations

from . import ast_nodes as ast
from .errors import error
from .lexer import Token, detectar_idioma, tokenize
from .tokens import TokenType as T

_COMPARADORES = {
    T.KW_IS: "==",
    T.OP_NEQ: "!=",
    T.OP_GT: ">",
    T.OP_LT: "<",
    T.OP_GTE: ">=",
    T.OP_LTE: "<=",
}

_MATEMATICOS = {
    T.OP_ADD: "+",
    T.OP_SUB: "-",
    T.OP_MUL: "*",
    T.OP_DIV: "/",
}


def parse(fuente: str, idioma: str | None = None) -> ast.Programa:
    """Analiza el texto completo de un programa y devuelve su árbol."""
    idioma = idioma or detectar_idioma(fuente)
    return Parser(tokenize(fuente, idioma), idioma).programa()


class Parser:
    def __init__(self, fichas: list[Token], idioma: str):
        self.fichas = fichas
        self.idioma = idioma
        self.pos = 0

    # --- utilidades ---

    @property
    def actual(self) -> Token:
        return self.fichas[self.pos]

    @property
    def siguiente(self) -> Token:
        return self.fichas[min(self.pos + 1, len(self.fichas) - 1)]

    def avanzar(self) -> Token:
        ficha = self.actual
        self.pos += 1
        return ficha

    def consumir(self, tipo: T, clave: str, **datos) -> Token:
        if self.actual.type is not tipo:
            self._error(clave, **datos)
        return self.avanzar()

    def _error(self, clave: str, **datos):
        if self.actual.type in _MATEMATICOS:
            raise error(self.idioma, "parser.calculo_sin_parentesis", self.actual.line)
        raise error(self.idioma, clave, self.actual.line, **datos)

    def fin_de_sentencia(self):
        self.consumir(T.NEWLINE, "parser.fin_de_frase")

    def dos_puntos_y_salto(self, quien: str):
        self.consumir(T.COLON, "parser.falta_dos_puntos", quien=quien)
        self.consumir(T.NEWLINE, "parser.bloque_nuevo", quien=quien)

    # --- programa y bloques ---

    def programa(self) -> ast.Programa:
        sentencias: list[ast.Nodo] = []
        while self.actual.type is not T.EOF:
            sentencias.append(self.sentencia(nivel_superior=True))
        return ast.Programa(1, sentencias)

    def bloque(self, cierres: tuple[T, ...]) -> list[ast.Nodo]:
        sentencias: list[ast.Nodo] = []
        while self.actual.type not in cierres:
            if self.actual.type is T.EOF:
                self._error("parser.falta_fin")
            sentencias.append(self.sentencia(nivel_superior=False))
        return sentencias

    def fin_de_bloque(self):
        self.consumir(T.KW_END, "parser.falta_fin")
        self.fin_de_sentencia()

    # --- sentencias ---

    def sentencia(self, nivel_superior: bool) -> ast.Nodo:
        tipo = self.actual.type
        if tipo is T.KW_WRITE:
            return self.escribe()
        if tipo is T.KW_IF:
            return self.condicional()
        if tipo is T.KW_FOREACH:
            return self.para_cada()
        if tipo is T.KW_REPEAT:
            return self.repite()
        if tipo is T.KW_WHILE:
            return self.mientras()
        if tipo is T.KW_DEFINE:
            if not nivel_superior:
                self._error("parser.define_en_bloque")
            return self.define()
        if tipo is T.KW_RETURN:
            return self.devuelve()
        if tipo is T.KW_SAVE:
            return self.guarda()
        if tipo is T.KW_APPEND:
            return self.anade()
        if tipo is T.NAME:
            if self.siguiente.type is T.KW_IS:
                return self.asignacion()
            return self.llamada_como_sentencia()
        self._error("parser.inicio_desconocido")

    def escribe(self) -> ast.Escribe:
        linea = self.avanzar().line
        expresion = self.expresion()
        self.fin_de_sentencia()
        return ast.Escribe(linea, expresion)

    def asignacion(self) -> ast.Asigna:
        nombre = self.avanzar()
        verbo = self.avanzar()  # es / son
        expresion = self.expresion()
        self.fin_de_sentencia()
        return ast.Asigna(nombre.line, nombre.value, expresion,
                          articulo=nombre.articulo, verbo=verbo.surface)

    def condicional(self) -> ast.Si:
        linea = self.avanzar().line
        condicion = self.expresion()
        self.dos_puntos_y_salto("si")
        entonces = self.bloque((T.KW_ELSE, T.KW_END))
        sino = None
        if self.actual.type is T.KW_ELSE:
            self.avanzar()
            self.dos_puntos_y_salto("si no")
            sino = self.bloque((T.KW_END,))
        self.fin_de_bloque()
        return ast.Si(linea, condicion, entonces, sino)

    def para_cada(self) -> ast.Nodo:
        linea = self.avanzar().line
        variable = self.consumir(T.NAME, "parser.para_cada_nombre").value
        if self.actual.type is T.KW_IN:
            self.avanzar()
            lista = self.expresion()
            self.dos_puntos_y_salto("para cada")
            cuerpo = self.bloque((T.KW_END,))
            self.fin_de_bloque()
            return ast.ParaCadaEnLista(linea, variable, lista, cuerpo)
        if self.actual.type is T.KW_FROM:
            self.avanzar()
            desde = self.primario()
            self.consumir(T.KW_TO, "parser.rango_al")
            hasta = self.primario()
            self.dos_puntos_y_salto("para cada")
            cuerpo = self.bloque((T.KW_END,))
            self.fin_de_bloque()
            return ast.ParaCadaEnRango(linea, variable, desde, hasta, cuerpo)
        self._error("parser.para_cada_en_o_del")

    def repite(self) -> ast.Repite:
        linea = self.avanzar().line
        veces = self.primario()
        self.consumir(T.KW_TIMES, "parser.repite_veces")
        self.dos_puntos_y_salto("repite")
        cuerpo = self.bloque((T.KW_END,))
        self.fin_de_bloque()
        return ast.Repite(linea, veces, cuerpo)

    def mientras(self) -> ast.Mientras:
        linea = self.avanzar().line
        condicion = self.expresion()
        self.dos_puntos_y_salto("mientras")
        cuerpo = self.bloque((T.KW_END,))
        self.fin_de_bloque()
        return ast.Mientras(linea, condicion, cuerpo)

    def define(self) -> ast.Define:
        linea = self.avanzar().line
        nombre = self.consumir(T.NAME, "parser.define_nombre").value
        parametros: list[str] = []
        if self.actual.type is T.KW_WITH:
            self.avanzar()
            parametros.append(self.consumir(T.NAME, "parser.con_parametros").value)
            while self.actual.type is T.COMMA:
                self.avanzar()
                parametros.append(self.consumir(T.NAME, "parser.otro_parametro").value)
        self.dos_puntos_y_salto("define")
        cuerpo = self.bloque((T.KW_END,))
        self.fin_de_bloque()
        return ast.Define(linea, nombre, parametros, cuerpo)

    def devuelve(self) -> ast.Devuelve:
        linea = self.avanzar().line
        expresion = None
        if self.actual.type is not T.NEWLINE:
            expresion = self.expresion()
        self.fin_de_sentencia()
        return ast.Devuelve(linea, expresion)

    def guarda(self) -> ast.Guarda:
        linea = self.avanzar().line
        valor = self.expresion()
        self.consumir(T.KW_IN, "parser.guarda_en")
        ruta = self.primario()
        self.fin_de_sentencia()
        return ast.Guarda(linea, valor, ruta)

    def anade(self) -> ast.Anade:
        linea = self.avanzar().line
        valor = self.expresion()
        self.consumir(T.KW_TO, "parser.anade_a")
        destino = self.primario()
        self.fin_de_sentencia()
        return ast.Anade(linea, valor, destino)

    def llamada_como_sentencia(self) -> ast.Llamada:
        llamada = self.llamada()
        self.fin_de_sentencia()
        return llamada

    # --- expresiones ---

    def expresion(self) -> ast.Nodo:
        return self.expr_o()

    def expr_o(self) -> ast.Nodo:
        izquierda = self.expr_y()
        while self.actual.type is T.OP_OR:
            linea = self.avanzar().line
            izquierda = ast.Binaria(linea, "or", izquierda, self.expr_y())
        return izquierda

    def expr_y(self) -> ast.Nodo:
        izquierda = self.comparacion()
        while self.actual.type is T.OP_AND:
            linea = self.avanzar().line
            izquierda = ast.Binaria(linea, "and", izquierda, self.comparacion())
        return izquierda

    def comparacion(self) -> ast.Nodo:
        izquierda = self.primario()
        if self.actual.type in _COMPARADORES:
            operador = _COMPARADORES[self.avanzar().type]
            derecha = self.primario()
            return ast.Binaria(izquierda.linea, operador, izquierda, derecha)
        return izquierda

    def primario(self) -> ast.Nodo:
        ficha = self.actual
        tipo = ficha.type
        if tipo is T.NUMBER:
            self.avanzar()
            return ast.Numero(ficha.line, ficha.value)
        if tipo is T.OP_SUB and self.siguiente.type is T.NUMBER:
            # un número negativo literal (-7) no es un cálculo (espec §5.1)
            self.avanzar()
            return ast.Numero(ficha.line, -self.avanzar().value)
        if tipo is T.STRING:
            self.avanzar()
            return self._texto_interpolado(ficha)
        if tipo is T.LIT_TRUE or tipo is T.LIT_FALSE:
            self.avanzar()
            return ast.Booleano(ficha.line, tipo is T.LIT_TRUE)
        if tipo is T.LIT_NOTHING:
            self.avanzar()
            return ast.Nada(ficha.line)
        if tipo is T.LBRACKET:
            return self.lista()
        if tipo is T.LPAREN:
            self.avanzar()
            dentro = self.calculo()
            self.consumir(T.RPAREN, "parser.falta_parentesis_cierre")
            return dentro
        if tipo is T.KW_ASK:
            self.avanzar()
            return ast.RespuestaA(ficha.line, self.primario())
        if tipo is T.KW_ELEMENT:
            self.avanzar()
            indice = self.primario()
            self.consumir(T.KW_OF, "parser.elemento_de")
            return ast.ElementoDe(ficha.line, indice, self.primario())
        if tipo is T.KW_FIRST:
            self.avanzar()
            return ast.PrimeroDe(ficha.line, self.primario())
        if tipo is T.KW_LAST:
            self.avanzar()
            return ast.UltimoDe(ficha.line, self.primario())
        if tipo is T.KW_COUNT:
            self.avanzar()
            return ast.CantidadDe(ficha.line, self.primario())
        if tipo is T.KW_CONTENTS:
            self.avanzar()
            return ast.ContenidoDe(ficha.line, self.primario())
        if tipo is T.KW_RANDOM:
            self.avanzar()
            desde = self.primario()
            self.consumir(T.OP_AND, "parser.azar_y")
            return ast.AlAzarEntre(ficha.line, desde, self.primario())
        if tipo is T.NAME:
            if self.siguiente.type is T.KW_WITH:
                return self.llamada()
            self.avanzar()
            return ast.Nombre(ficha.line, ficha.value, articulo=ficha.articulo)
        self._error("parser.valor_esperado")

    def calculo(self) -> ast.Nodo:
        """Dentro de los paréntesis: la isla donde viven + - * /."""
        return self.suma()

    def suma(self) -> ast.Nodo:
        izquierda = self.producto()
        while self.actual.type in (T.OP_ADD, T.OP_SUB):
            operador = _MATEMATICOS[self.avanzar().type]
            izquierda = ast.Binaria(izquierda.linea, operador, izquierda, self.producto())
        return izquierda

    def producto(self) -> ast.Nodo:
        izquierda = self.unario()
        while self.actual.type in (T.OP_MUL, T.OP_DIV):
            operador = _MATEMATICOS[self.avanzar().type]
            izquierda = ast.Binaria(izquierda.linea, operador, izquierda, self.unario())
        return izquierda

    def unario(self) -> ast.Nodo:
        if self.actual.type is T.OP_SUB:
            linea = self.avanzar().line
            return ast.MenosUnario(linea, self.unario())
        return self.primario()

    # --- llamadas ---

    def llamada(self) -> ast.Llamada:
        nombre = self.avanzar()
        argumentos: list[ast.Nodo] = []
        if self.actual.type is T.KW_WITH:
            self.avanzar()
            argumentos.append(self.argumento())
            while self.actual.type is T.COMMA:
                self.avanzar()
                argumentos.append(self.argumento())
        return ast.Llamada(nombre.line, nombre.value, argumentos)

    def argumento(self) -> ast.Nodo:
        if self.actual.type is T.NAME and self.siguiente.type is T.KW_WITH:
            raise error(self.idioma, "parser.llamada_anidada", self.actual.line)
        return self.primario()

    def lista(self) -> ast.Lista:
        linea = self.avanzar().line
        elementos: list[ast.Nodo] = []
        if self.actual.type is not T.RBRACKET:
            elementos.append(self.elemento_de_lista())
            while self.actual.type is T.COMMA:
                self.avanzar()
                elementos.append(self.elemento_de_lista())
        self.consumir(T.RBRACKET, "parser.falta_parentesis_cierre")
        return ast.Lista(linea, elementos)

    def elemento_de_lista(self) -> ast.Nodo:
        if self.actual.type is T.NAME and self.siguiente.type is T.KW_WITH:
            raise error(self.idioma, "parser.llamada_en_lista", self.actual.line)
        return self.primario()

    # --- interpolación de textos ---

    def _texto_interpolado(self, ficha: Token) -> ast.Texto:
        partes: list = []
        literal = ""
        texto = ficha.value
        i = 0
        while i < len(texto):
            caracter = texto[i]
            if texto.startswith("{{", i):
                literal += "{"
                i += 2
            elif texto.startswith("}}", i):
                literal += "}"
                i += 2
            elif caracter == "{":
                cierre = texto.find("}", i + 1)
                if cierre == -1:
                    raise error(self.idioma, "parser.llave_sin_cerrar", ficha.line)
                if literal:
                    partes.append(literal)
                    literal = ""
                partes.append(self._expresion_interpolada(texto[i + 1:cierre], ficha.line))
                i = cierre + 1
            elif caracter == "}":
                raise error(self.idioma, "parser.llave_de_mas", ficha.line)
            else:
                literal += caracter
                i += 1
        if literal or not partes:
            partes.append(literal)
        return ast.Texto(ficha.line, partes)

    def _expresion_interpolada(self, fragmento: str, linea: int) -> ast.Nodo:
        """Las llaves de la interpolación ya delimitan: dentro va un cálculo sin paréntesis."""
        fichas = tokenize(fragmento, self.idioma)
        interno = Parser(fichas, self.idioma)
        expresion = interno.calculo()
        if interno.actual.type is not T.NEWLINE:
            raise error(self.idioma, "parser.calculo_interpolado", linea, fragmento=fragmento)
        return expresion
