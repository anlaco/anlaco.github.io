"""Emisor de Anlaco: convierte el árbol del programa otra vez en texto.

Es la pieza compartida por dos comandos:

- anlaco formatear: reescribe el programa en su forma canónica (indentación de
  4 espacios, símbolos matemáticos, un espacio alrededor de los operadores),
  conservando artículos, es/son y comentarios tal como estaban. Propiedad
  clave para el código de IA: dos programas equivalentes quedan idénticos.

- anlaco traducir: emite el programa con la tabla de otro idioma. Los
  identificadores, los textos y los comentarios no se traducen (v0.1); los
  artículos se omiten (son decorativos y el género no se puede adivinar);
  es/son se corresponden con is/are por su posición en la tabla.
"""

from __future__ import annotations

import re

from . import ast_nodes as ast
from .lexer import detectar_idioma, frases_de_idioma
from .parser import parse
from .tokens import TokenType as T

_RE_DIRECTIVA = re.compile(r"^#\s*idioma\s*:")

_PRECEDENCIA = {"+": 1, "-": 1, "*": 2, "/": 2}
_MATEMATICOS = ("+", "-", "*", "/")
_COMPARADORES = {"==": None, "!=": T.OP_NEQ, ">": T.OP_GT, "<": T.OP_LT,
                 ">=": T.OP_GTE, "<=": T.OP_LTE}


def formatear(fuente: str, idioma: str | None = None) -> str:
    """La forma canónica del programa, en su mismo idioma."""
    idioma = idioma or detectar_idioma(fuente)
    programa = parse(fuente, idioma)
    emisor = Emisor(idioma, conservar=True, fuente=fuente)
    return emisor.programa(programa)


def traducir(fuente: str, destino: str, origen: str | None = None) -> str:
    """El mismo programa, con las palabras de otro idioma."""
    origen = origen or detectar_idioma(fuente)
    programa = parse(fuente, origen)
    emisor = Emisor(destino, conservar=False, fuente=fuente,
                    frases_origen=frases_de_idioma(origen))
    cuerpo = emisor.programa(programa, sin_directivas=True)
    return f"# idioma: {destino}\n{cuerpo}"


class Emisor:
    def __init__(self, idioma: str, conservar: bool, fuente: str,
                 frases_origen: dict | None = None):
        self.frases = frases_de_idioma(idioma)
        self.conservar = conservar
        self.frases_origen = frases_origen
        # comentarios y líneas en blanco del original, por número de línea
        self.comentarios: dict[int, str] = {}
        self.blancos: set[int] = set()
        for numero, linea in enumerate(fuente.splitlines(), 1):
            limpia = linea.strip()
            if limpia.startswith("#"):
                self.comentarios[numero] = limpia
            elif limpia == "":
                self.blancos.add(numero)
        self.lineas: list[str] = []
        self.cursor = 0  # última línea del original ya recorrida

    def frase(self, tipo: T, indice: int = 0) -> str:
        opciones = self.frases[tipo]
        return opciones[min(indice, len(opciones) - 1)]

    # --- estructura ---

    def programa(self, programa: ast.Programa, sin_directivas: bool = False) -> str:
        self.sin_directivas = sin_directivas
        self._bloque(programa.sentencias, nivel=0)
        self._hueco(10 ** 9, nivel=0)  # comentarios que quedaran al final
        while self.lineas and self.lineas[-1] == "":
            self.lineas.pop()
        return "\n".join(self.lineas) + "\n"

    def _bloque(self, sentencias: list[ast.Nodo], nivel: int):
        for sentencia in sentencias:
            self._hueco(sentencia.linea, nivel)
            self._sentencia(sentencia, nivel)

    def _hueco(self, hasta: int, nivel: int):
        """Reproduce los comentarios y (una) línea en blanco del original."""
        pendientes = sorted(numero for numero in (self.blancos | set(self.comentarios))
                            if self.cursor < numero < hasta)
        blanco_pendiente = False
        for numero in pendientes:
            if numero in self.blancos:
                blanco_pendiente = bool(self.lineas)
            else:
                comentario = self.comentarios[numero]
                if self.sin_directivas and _RE_DIRECTIVA.match(comentario):
                    continue
                if blanco_pendiente:
                    self.lineas.append("")
                    blanco_pendiente = False
                self.lineas.append("    " * nivel + comentario)
        if blanco_pendiente:
            self.lineas.append("")
        self.cursor = max(self.cursor, hasta - 1)

    def _linea(self, nivel: int, texto: str, linea_original: int):
        self.lineas.append("    " * nivel + texto)
        self.cursor = max(self.cursor, linea_original)

    # --- sentencias ---

    def _sentencia(self, nodo: ast.Nodo, nivel: int):
        if isinstance(nodo, ast.Escribe):
            self._linea(nivel, f"{self.frase(T.KW_WRITE)} {self.expresion(nodo.expresion)}", nodo.linea)
        elif isinstance(nodo, ast.Asigna):
            self._linea(nivel, self._asignacion(nodo), nodo.linea)
        elif isinstance(nodo, ast.Si):
            self._linea(nivel, f"{self.frase(T.KW_IF)} {self.expresion(nodo.condicion)}:", nodo.linea)
            self._bloque(nodo.entonces, nivel + 1)
            if nodo.sino is not None:
                self._linea(nivel, f"{self.frase(T.KW_ELSE)}:", self.cursor)
                self._bloque(nodo.sino, nivel + 1)
            self._fin(nivel)
        elif isinstance(nodo, ast.ParaCadaEnLista):
            self._linea(nivel, f"{self.frase(T.KW_FOREACH)} {nodo.variable} "
                               f"{self.frase(T.KW_IN)} {self.expresion(nodo.lista)}:", nodo.linea)
            self._bloque(nodo.cuerpo, nivel + 1)
            self._fin(nivel)
        elif isinstance(nodo, ast.ParaCadaEnRango):
            self._linea(nivel, f"{self.frase(T.KW_FOREACH)} {nodo.variable} "
                               f"{self.frase(T.KW_FROM)} {self.atomo(nodo.desde)} "
                               f"{self.frase(T.KW_TO, 0)} {self.atomo(nodo.hasta)}:", nodo.linea)
            self._bloque(nodo.cuerpo, nivel + 1)
            self._fin(nivel)
        elif isinstance(nodo, ast.Repite):
            self._linea(nivel, f"{self.frase(T.KW_REPEAT)} {self.atomo(nodo.veces)} "
                               f"{self.frase(T.KW_TIMES)}:", nodo.linea)
            self._bloque(nodo.cuerpo, nivel + 1)
            self._fin(nivel)
        elif isinstance(nodo, ast.Mientras):
            self._linea(nivel, f"{self.frase(T.KW_WHILE)} {self.expresion(nodo.condicion)}:", nodo.linea)
            self._bloque(nodo.cuerpo, nivel + 1)
            self._fin(nivel)
        elif isinstance(nodo, ast.Define):
            cabecera = f"{self.frase(T.KW_DEFINE)} {nodo.nombre}"
            if nodo.parametros:
                cabecera += f" {self.frase(T.KW_WITH)} " + ", ".join(nodo.parametros)
            self._linea(nivel, cabecera + ":", nodo.linea)
            self._bloque(nodo.cuerpo, nivel + 1)
            self._fin(nivel)
        elif isinstance(nodo, ast.Devuelve):
            texto = self.frase(T.KW_RETURN)
            if nodo.expresion is not None:
                texto += f" {self.expresion(nodo.expresion)}"
            self._linea(nivel, texto, nodo.linea)
        elif isinstance(nodo, ast.Guarda):
            self._linea(nivel, f"{self.frase(T.KW_SAVE)} {self.expresion(nodo.valor)} "
                               f"{self.frase(T.KW_IN)} {self.atomo(nodo.ruta)}", nodo.linea)
        elif isinstance(nodo, ast.Anade):
            self._linea(nivel, f"{self.frase(T.KW_APPEND)} {self.expresion(nodo.valor)} "
                               f"{self.frase(T.KW_TO, 1)} {self.atomo(nodo.destino)}", nodo.linea)
        elif isinstance(nodo, ast.Llamada):
            self._linea(nivel, self.llamada(nodo), nodo.linea)

    def _fin(self, nivel: int):
        self._linea(nivel, self.frase(T.KW_END), self.cursor)

    def _asignacion(self, nodo: ast.Asigna) -> str:
        if self.conservar:
            articulo = f"{nodo.articulo} " if nodo.articulo else ""
            verbo = nodo.verbo or self.frase(T.KW_IS)
        else:
            articulo = ""
            verbo = self._traducir_verbo(nodo.verbo)
        return f"{articulo}{nodo.nombre} {verbo} {self.expresion(nodo.expresion)}"

    def _traducir_verbo(self, verbo: str | None) -> str:
        if verbo is None or self.frases_origen is None:
            return self.frase(T.KW_IS)
        origen = self.frases_origen[T.KW_IS]
        indice = origen.index(verbo) if verbo in origen else 0
        return self.frase(T.KW_IS, indice)

    # --- expresiones ---

    def expresion(self, nodo: ast.Nodo) -> str:
        """Una expresión en posición de prosa (los cálculos van entre paréntesis)."""
        if isinstance(nodo, ast.Binaria):
            if nodo.operador in _MATEMATICOS:
                return f"({self.calculo(nodo)})"
            if nodo.operador == "and":
                return f"{self.expresion(nodo.izquierda)} {self.frase(T.OP_AND)} {self.expresion(nodo.derecha)}"
            if nodo.operador == "or":
                return f"{self.expresion(nodo.izquierda)} {self.frase(T.OP_OR)} {self.expresion(nodo.derecha)}"
            comparador = (self.frase(T.KW_IS) if nodo.operador == "=="
                          else self.frase(_COMPARADORES[nodo.operador]))
            return f"{self.atomo(nodo.izquierda)} {comparador} {self.atomo(nodo.derecha)}"
        if isinstance(nodo, ast.MenosUnario):
            return f"({self.calculo(nodo)})"
        return self.atomo(nodo)

    def calculo(self, nodo: ast.Nodo, precedencia: int = 0, derecha: bool = False) -> str:
        """Dentro de la isla: símbolos con la precedencia escolar."""
        if isinstance(nodo, ast.Binaria) and nodo.operador in _MATEMATICOS:
            propia = _PRECEDENCIA[nodo.operador]
            texto = (f"{self.calculo(nodo.izquierda, propia)} {nodo.operador} "
                     f"{self.calculo(nodo.derecha, propia, derecha=True)}")
            if propia < precedencia or (derecha and propia == precedencia):
                return f"({texto})"
            return texto
        if isinstance(nodo, ast.MenosUnario):
            interior = self.calculo(nodo.expresion, 3)
            return f"-{interior}"
        if isinstance(nodo, ast.Llamada):
            return self.llamada(nodo)
        return self.atomo(nodo)

    def atomo(self, nodo: ast.Nodo) -> str:
        if isinstance(nodo, ast.Numero):
            return str(nodo.valor)
        if isinstance(nodo, ast.Booleano):
            return self.frase(T.LIT_TRUE if nodo.valor else T.LIT_FALSE)
        if isinstance(nodo, ast.Nada):
            return self.frase(T.LIT_NOTHING)
        if isinstance(nodo, ast.Nombre):
            if self.conservar and nodo.articulo:
                return f"{nodo.articulo} {nodo.nombre}"
            return nodo.nombre
        if isinstance(nodo, ast.Texto):
            return self._texto(nodo)
        if isinstance(nodo, ast.Lista):
            elementos = []
            for elemento in nodo.elementos:
                if isinstance(elemento, ast.Llamada) and elemento.argumentos:
                    elementos.append(f"({self.llamada(elemento)})")
                else:
                    elementos.append(self.atomo(elemento))
            return "[" + ", ".join(elementos) + "]"
        if isinstance(nodo, ast.RespuestaA):
            return f"{self.frase(T.KW_ASK)} {self.atomo(nodo.pregunta)}"
        if isinstance(nodo, ast.ElementoDe):
            return (f"{self.frase(T.KW_ELEMENT)} {self.atomo(nodo.indice)} "
                    f"{self.frase(T.KW_OF)} {self.atomo(nodo.coleccion)}")
        if isinstance(nodo, ast.PrimeroDe):
            return f"{self.frase(T.KW_FIRST)} {self.atomo(nodo.coleccion)}"
        if isinstance(nodo, ast.UltimoDe):
            return f"{self.frase(T.KW_LAST)} {self.atomo(nodo.coleccion)}"
        if isinstance(nodo, ast.CantidadDe):
            return f"{self.frase(T.KW_COUNT)} {self.atomo(nodo.coleccion)}"
        if isinstance(nodo, ast.ContenidoDe):
            return f"{self.frase(T.KW_CONTENTS)} {self.atomo(nodo.ruta)}"
        if isinstance(nodo, ast.AlAzarEntre):
            return (f"{self.frase(T.KW_RANDOM)} {self.atomo(nodo.desde)} "
                    f"{self.frase(T.OP_AND)} {self.atomo(nodo.hasta)}")
        if isinstance(nodo, ast.Llamada):
            return self.llamada(nodo)
        if isinstance(nodo, (ast.Binaria, ast.MenosUnario)):
            return f"({self.calculo(nodo)})"
        raise ValueError(f"No sé emitir {type(nodo).__name__}")

    def llamada(self, nodo: ast.Llamada) -> str:
        if not nodo.argumentos:
            return nodo.nombre
        partes = []
        for argumento in nodo.argumentos:
            if isinstance(argumento, (ast.Binaria, ast.MenosUnario)):
                partes.append(f"({self.calculo(argumento)})")
            elif isinstance(argumento, ast.Llamada) and argumento.argumentos:
                partes.append(f"({self.llamada(argumento)})")
            else:
                partes.append(self.atomo(argumento))
        return f"{nodo.nombre} {self.frase(T.KW_WITH)} " + ", ".join(partes)

    def _texto(self, nodo: ast.Texto) -> str:
        trozos = []
        for parte in nodo.partes:
            if isinstance(parte, str):
                trozos.append(parte.replace("{", "{{").replace("}", "}}"))
            else:
                trozos.append("{" + self.calculo(parte) + "}")
        return '"' + "".join(trozos) + '"'
