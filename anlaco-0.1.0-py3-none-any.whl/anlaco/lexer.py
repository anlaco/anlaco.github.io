"""Lexer de Anlaco: convierte el texto de un programa .ana en fichas (tokens).

Este es el ÚNICO módulo que sabe de idiomas. Cada idioma es una tabla
keywords/XX.toml (frase escrita -> ficha canónica); a partir de aquí, todo el
intérprete trabaja con fichas neutras.

Reglas que implementa (ver espec/especificacion.md):
- frases multi-palabra por coincidencia voraz: "es mayor o igual que" gana a "es"
- los artículos (el, la, the, ...) se descartan, pero quedan apuntados en la
  ficha del nombre que acompañan (el formateador los conserva)
- los alias de palabra (más, por, plus, ...) se convierten en + - * /
- la indentación NO significa nada: la estructura la dan ":" y "fin"
- el idioma se declara con "# idioma: XX" o se detecta automáticamente
"""

from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass
from pathlib import Path

from .errors import error
from .tokens import TokenType

KEYWORDS_DIR = Path(__file__).parent / "keywords"

_RE_DIRECTIVA_IDIOMA = re.compile(r"^\s*#\s*idioma\s*:\s*([a-z]+)\s*$", re.MULTILINE)
_RE_NUMERO = re.compile(r"\d+(\.\d+)?")
_RE_PALABRA = re.compile(r"[^\W\d_]\w*", re.UNICODE)  # empieza por letra (incluye ñ, á...)

_SIMBOLOS = {
    "(": TokenType.LPAREN,
    ")": TokenType.RPAREN,
    "[": TokenType.LBRACKET,
    "]": TokenType.RBRACKET,
    ",": TokenType.COMMA,
    ":": TokenType.COLON,
    "+": TokenType.OP_ADD,
    "-": TokenType.OP_SUB,
    "*": TokenType.OP_MUL,
    "/": TokenType.OP_DIV,
}


@dataclass(frozen=True)
class Token:
    type: TokenType
    value: object       # nombre, valor numérico o contenido del texto
    surface: str        # tal cual se escribió (lo usa el formateador)
    line: int
    articulo: str | None = None  # el artículo que acompañaba a este nombre, si lo había

    def __repr__(self) -> str:
        return f"{self.type.name}({self.value!r}, línea {self.line})"


class TablaDeIdioma:
    def __init__(self, codigo: str, articulos: list[str], frases: dict[tuple[str, ...], TokenType]):
        self.codigo = codigo
        self.articulos = set(articulos)
        self.frases = frases
        self.longitud_maxima = max(len(frase) for frase in frases)
        self.palabras_conocidas = {palabra for frase in frases for palabra in frase}


def idiomas_disponibles() -> list[str]:
    return sorted(ruta.stem for ruta in KEYWORDS_DIR.glob("*.toml"))


def cargar_idioma(codigo: str) -> TablaDeIdioma:
    ruta = KEYWORDS_DIR / f"{codigo}.toml"
    if not ruta.exists():
        raise error("es", "lexer.idioma_desconocido", codigo=codigo,
                    disponibles=", ".join(idiomas_disponibles()))
    datos = tomllib.loads(ruta.read_text("utf-8"))
    frases = {tuple(frase.split()): TokenType[nombre] for frase, nombre in datos["keywords"].items()}
    return TablaDeIdioma(codigo, datos["articles"], frases)


def frases_de_idioma(codigo: str) -> dict[TokenType, list[str]]:
    """Las frases de cada ficha, en el orden del TOML (lo usa el emisor)."""
    datos = tomllib.loads((KEYWORDS_DIR / f"{codigo}.toml").read_text("utf-8"))
    resultado: dict[TokenType, list[str]] = {}
    for frase, nombre in datos["keywords"].items():
        resultado.setdefault(TokenType[nombre], []).append(frase)
    return resultado


def detectar_idioma(fuente: str) -> str:
    """Devuelve el código de idioma del programa.

    Manda la directiva "# idioma: XX" si existe; si no, gana la tabla cuyas
    palabras clave aparecen más veces en el texto.
    """
    directiva = _RE_DIRECTIVA_IDIOMA.search(fuente)
    if directiva:
        return directiva.group(1)

    palabras = _RE_PALABRA.findall(fuente)
    puntuaciones: dict[str, int] = {}
    for codigo in idiomas_disponibles():
        tabla = cargar_idioma(codigo)
        puntuaciones[codigo] = sum(1 for palabra in palabras if palabra in tabla.palabras_conocidas)
    mejor = max(puntuaciones, key=lambda codigo: puntuaciones[codigo])
    if puntuaciones[mejor] == 0:
        raise error("es", "lexer.idioma_no_reconocido")
    return mejor


def tokenize(fuente: str, idioma: str | None = None) -> list[Token]:
    """Convierte el texto completo de un programa en la lista de fichas."""
    tabla = cargar_idioma(idioma or detectar_idioma(fuente))
    fichas: list[Token] = []
    for numero, linea in enumerate(fuente.splitlines(), 1):
        brutos = _escanear_linea(linea, numero, tabla.codigo)
        fichas_de_linea = _resolver_frases(brutos, tabla, numero)
        if fichas_de_linea:
            fichas.extend(fichas_de_linea)
            fichas.append(Token(TokenType.NEWLINE, None, "", numero))
    fichas.append(Token(TokenType.EOF, None, "", len(fuente.splitlines()) + 1))
    return fichas


# --- primera pasada: caracteres -> piezas brutas (palabra, número, texto, símbolo) ---

@dataclass(frozen=True)
class _Pieza:
    clase: str        # "palabra" | "numero" | "texto" | "simbolo"
    valor: object
    surface: str


def _escanear_linea(linea: str, numero: int, idioma: str) -> list[_Pieza]:
    piezas: list[_Pieza] = []
    i = 0
    while i < len(linea):
        caracter = linea[i]
        if caracter in " \t":
            i += 1
        elif caracter == "#":
            break  # comentario hasta el final de la línea
        elif caracter == '"':
            cierre = linea.find('"', i + 1)
            if cierre == -1:
                raise error(idioma, "lexer.texto_sin_cerrar", numero)
            piezas.append(_Pieza("texto", linea[i + 1:cierre], linea[i:cierre + 1]))
            i = cierre + 1
        elif caracter.isdigit():
            coincidencia = _RE_NUMERO.match(linea, i)
            texto = coincidencia.group()
            valor = float(texto) if "." in texto else int(texto)
            piezas.append(_Pieza("numero", valor, texto))
            i = coincidencia.end()
        elif caracter in _SIMBOLOS:
            piezas.append(_Pieza("simbolo", caracter, caracter))
            i += 1
        else:
            coincidencia = _RE_PALABRA.match(linea, i)
            if not coincidencia:
                raise error(idioma, "lexer.caracter_desconocido", numero, caracter=caracter)
            piezas.append(_Pieza("palabra", coincidencia.group(), coincidencia.group()))
            i = coincidencia.end()
    return piezas


# --- segunda pasada: piezas -> fichas canónicas (frases voraces, artículos fuera) ---

def _resolver_frases(piezas: list[_Pieza], tabla: TablaDeIdioma, numero: int) -> list[Token]:
    fichas: list[Token] = []
    articulo_pendiente: str | None = None
    j = 0
    while j < len(piezas):
        pieza = piezas[j]
        if pieza.clase == "palabra":
            frase = _frase_mas_larga(piezas, j, tabla)
            if frase is not None:
                tipo, longitud = frase
                surface = " ".join(p.surface for p in piezas[j:j + longitud])
                fichas.append(Token(tipo, surface, surface, numero))
                articulo_pendiente = None
                j += longitud
            elif pieza.valor in tabla.articulos:
                articulo_pendiente = pieza.surface  # decorativo: se apunta y se descarta
                j += 1
            else:
                fichas.append(Token(TokenType.NAME, pieza.valor, pieza.surface, numero,
                                    articulo=articulo_pendiente))
                articulo_pendiente = None
                j += 1
        elif pieza.clase == "numero":
            fichas.append(Token(TokenType.NUMBER, pieza.valor, pieza.surface, numero))
            articulo_pendiente = None
            j += 1
        elif pieza.clase == "texto":
            fichas.append(Token(TokenType.STRING, pieza.valor, pieza.surface, numero))
            articulo_pendiente = None
            j += 1
        else:
            fichas.append(Token(_SIMBOLOS[pieza.valor], pieza.valor, pieza.surface, numero))
            articulo_pendiente = None
            j += 1
    return fichas


def _frase_mas_larga(piezas: list[_Pieza], j: int, tabla: TablaDeIdioma) -> tuple[TokenType, int] | None:
    """Busca la frase de palabras clave más larga que empiece en piezas[j]."""
    tope = min(tabla.longitud_maxima, len(piezas) - j)
    for longitud in range(tope, 0, -1):
        trozo = piezas[j:j + longitud]
        if not all(pieza.clase == "palabra" for pieza in trozo):
            continue
        candidata = tuple(pieza.valor for pieza in trozo)
        if candidata in tabla.frases:
            return tabla.frases[candidata], longitud
    return None


if __name__ == "__main__":
    # Demostración: python -m anlaco.lexer archivo.ana
    import sys

    codigo_fuente = Path(sys.argv[1]).read_text("utf-8")
    for ficha in tokenize(codigo_fuente):
        print(f"{ficha.line:4}  {ficha.type.name:12} {ficha.value!r}")
