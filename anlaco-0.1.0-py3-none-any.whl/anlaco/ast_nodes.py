"""Nodos del árbol del programa (AST) de Anlaco.

El árbol es el contrato central del lenguaje: es completamente neutro (no sabe
de idiomas) y sobre él trabajan el intérprete de hoy y el compilador de mañana.
Dos programas equivalentes en español y en inglés producen árboles IDÉNTICOS.

La comparación de nodos ignora el número de línea (compare=False): dos árboles
son iguales si su estructura lo es, aunque vengan de archivos distintos.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Nodo:
    linea: int = field(compare=False)


# --- programa y sentencias ---

@dataclass
class Programa(Nodo):
    sentencias: list[Nodo]


@dataclass
class Escribe(Nodo):
    expresion: Nodo


@dataclass
class Asigna(Nodo):
    nombre: str
    expresion: Nodo
    # cómo se escribió (lo conserva el formateador; no afecta a la igualdad):
    articulo: str | None = field(default=None, compare=False)
    verbo: str | None = field(default=None, compare=False)  # "es" o "son"


@dataclass
class Si(Nodo):
    condicion: Nodo
    entonces: list[Nodo]
    sino: list[Nodo] | None


@dataclass
class ParaCadaEnLista(Nodo):
    variable: str
    lista: Nodo
    cuerpo: list[Nodo]


@dataclass
class ParaCadaEnRango(Nodo):
    variable: str
    desde: Nodo
    hasta: Nodo
    cuerpo: list[Nodo]


@dataclass
class Repite(Nodo):
    veces: Nodo
    cuerpo: list[Nodo]


@dataclass
class Mientras(Nodo):
    condicion: Nodo
    cuerpo: list[Nodo]


@dataclass
class Define(Nodo):
    nombre: str
    parametros: list[str]
    cuerpo: list[Nodo]


@dataclass
class Devuelve(Nodo):
    expresion: Nodo | None


@dataclass
class Guarda(Nodo):
    valor: Nodo
    ruta: Nodo


@dataclass
class Anade(Nodo):
    valor: Nodo
    destino: Nodo


# --- expresiones ---

@dataclass
class Numero(Nodo):
    valor: int | float


@dataclass
class Texto(Nodo):
    """Un texto con su interpolación ya analizada.

    partes alterna literales (str) y expresiones (Nodo):
    "Te faltan {faltan} años"  ->  ["Te faltan ", Nombre("faltan"), " años"]
    """
    partes: list


@dataclass
class Booleano(Nodo):
    valor: bool


@dataclass
class Nada(Nodo):
    pass


@dataclass
class Nombre(Nodo):
    nombre: str
    articulo: str | None = field(default=None, compare=False)


@dataclass
class Lista(Nodo):
    elementos: list[Nodo]


@dataclass
class Binaria(Nodo):
    """Operación con dos lados. Operadores canónicos neutros:
    matemáticas: + - * /   comparación: == != > < >= <=   lógica: and or
    """
    operador: str
    izquierda: Nodo
    derecha: Nodo


@dataclass
class MenosUnario(Nodo):
    expresion: Nodo


@dataclass
class Llamada(Nodo):
    nombre: str
    argumentos: list[Nodo]


@dataclass
class RespuestaA(Nodo):
    pregunta: Nodo


@dataclass
class ElementoDe(Nodo):
    indice: Nodo
    coleccion: Nodo


@dataclass
class PrimeroDe(Nodo):
    coleccion: Nodo


@dataclass
class UltimoDe(Nodo):
    coleccion: Nodo


@dataclass
class CantidadDe(Nodo):
    coleccion: Nodo


@dataclass
class ContenidoDe(Nodo):
    ruta: Nodo


@dataclass
class AlAzarEntre(Nodo):
    desde: Nodo
    hasta: Nodo
