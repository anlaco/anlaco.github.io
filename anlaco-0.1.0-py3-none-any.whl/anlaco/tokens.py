"""Fichas (tokens) canónicas de Anlaco.

Estas fichas son neutras: no saben de español ni de inglés. La correspondencia
entre las palabras de cada idioma y estas fichas vive en keywords/XX.toml.
"""

from enum import Enum, auto


class TokenType(Enum):
    # Sentencias
    KW_WRITE = auto()      # escribe / write
    KW_IS = auto()         # es, son / is, are
    KW_IF = auto()         # si / if
    KW_ELSE = auto()       # si no / otherwise
    KW_END = auto()        # fin / end
    KW_FOREACH = auto()    # para cada / for each
    KW_IN = auto()         # en / in
    KW_FROM = auto()       # del / from
    KW_TO = auto()         # al, a / to
    KW_REPEAT = auto()     # repite / repeat
    KW_TIMES = auto()      # veces / times
    KW_WHILE = auto()      # mientras / while
    KW_DEFINE = auto()     # define / define
    KW_WITH = auto()       # con / with
    KW_RETURN = auto()     # devuelve / return
    KW_SAVE = auto()       # guarda / save
    KW_APPEND = auto()     # añade / append

    # Frases nominales (expresiones)
    KW_ASK = auto()        # respuesta a / answer to
    KW_ELEMENT = auto()    # elemento / element
    KW_OF = auto()         # de / of
    KW_FIRST = auto()      # primero de / first of
    KW_LAST = auto()       # último de / last of
    KW_COUNT = auto()      # cantidad de / count of
    KW_CONTENTS = auto()   # contenido de / contents of
    KW_RANDOM = auto()     # al azar entre / at random between

    # Lógica y comparaciones
    OP_AND = auto()        # y / and
    OP_OR = auto()         # o / or
    OP_NEQ = auto()        # no es / is not
    OP_GT = auto()         # es mayor que / is greater than
    OP_LT = auto()         # es menor que / is less than
    OP_GTE = auto()        # es mayor o igual que / is greater than or equal to
    OP_LTE = auto()        # es menor o igual que / is less than or equal to

    # Matemáticas (símbolos; las palabras más/menos/por/entre son alias)
    OP_ADD = auto()
    OP_SUB = auto()
    OP_MUL = auto()
    OP_DIV = auto()

    # Literales
    LIT_TRUE = auto()      # verdadero / true
    LIT_FALSE = auto()     # falso / false
    LIT_NOTHING = auto()   # nada / nothing

    # Puntuación
    LPAREN = auto()
    RPAREN = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    COMMA = auto()
    COLON = auto()

    # Con contenido
    NAME = auto()          # identificador
    NUMBER = auto()        # 42, 3.14
    STRING = auto()        # "texto" (con la interpolación {} aún sin procesar)

    # Estructura
    NEWLINE = auto()
    EOF = auto()
