"""Ensamblador de WAT a binario `.wasm`, en Python puro.

El compilador de Anlaco emite el módulo como texto WAT (S-expresiones) sobre el
preludio escrito a mano. El navegador y las herramientas de despliegue necesitan
el binario; esta pieza lo produce sin depender de wasm-tools ni de nada externo,
de modo que Pyodide puede fabricar el `.wasm` en el propio navegador y, el día
del autoalojamiento, el codificador es portable a Anlaco.

No es un ensamblador general de WAT: cubre exactamente el subconjunto que el
compilador y el preludio emiten (WasmGC + WASI, sin tablas, sin call_indirect,
sin br_table, con datos pasivos). La única fuente de verdad sigue siendo el WAT;
esto lo traduce a bytes. wasmtime valida al cargar, así que un `.wasm` que corre
es un `.wasm` bien codificado.
"""

from __future__ import annotations

import struct


# --------------------------------------------------------------------------- #
# 1. Tokenizador y lector de S-expresiones
# --------------------------------------------------------------------------- #

class Cadena:
    """Un literal de texto del WAT, ya decodificado a bytes."""

    __slots__ = ("bytes",)

    def __init__(self, datos: bytes):
        self.bytes = datos


def _tokenizar(texto: str):
    i = 0
    n = len(texto)
    while i < n:
        c = texto[i]
        if c in " \t\r\n":
            i += 1
            continue
        if c == ";" and i + 1 < n and texto[i + 1] == ";":
            j = texto.find("\n", i)
            i = n if j == -1 else j + 1
            continue
        if c == "(" and i + 1 < n and texto[i + 1] == ";":
            profundidad = 1
            i += 2
            while i < n and profundidad:
                if texto[i] == "(" and i + 1 < n and texto[i + 1] == ";":
                    profundidad += 1
                    i += 2
                elif texto[i] == ";" and i + 1 < n and texto[i + 1] == ")":
                    profundidad -= 1
                    i += 2
                else:
                    i += 1
            continue
        if c in "()":
            yield c
            i += 1
            continue
        if c == '"':
            datos = bytearray()
            i += 1
            while i < n and texto[i] != '"':
                if texto[i] == "\\":
                    e = texto[i + 1]
                    if e == "n":
                        datos.append(0x0A); i += 2
                    elif e == "t":
                        datos.append(0x09); i += 2
                    elif e == "r":
                        datos.append(0x0D); i += 2
                    elif e in '"\\\'':
                        datos.append(ord(e)); i += 2
                    elif e == "u":
                        fin = texto.find("}", i)
                        cp = int(texto[i + 3:fin], 16)
                        datos.extend(chr(cp).encode("utf-8")); i = fin + 1
                    else:
                        datos.append(int(texto[i + 1:i + 3], 16)); i += 3
                else:
                    datos.extend(texto[i].encode("utf-8")); i += 1
            i += 1
            yield Cadena(bytes(datos))
            continue
        # átomo: hasta espacio, paréntesis o comienzo de comentario
        j = i
        while j < n and texto[j] not in " \t\r\n()\"" and not (
                texto[j] == ";" and j + 1 < n and texto[j + 1] == ";"):
            j += 1
        yield texto[i:j]
        i = j


def leer_sexpr(texto: str):
    """El WAT como listas anidadas; los átomos son str y los textos son Cadena."""
    it = _tokenizar(texto)
    pila = [[]]
    for tok in it:
        if tok == "(":
            nueva = []
            pila[-1].append(nueva)
            pila.append(nueva)
        elif tok == ")":
            pila.pop()
        else:
            pila[-1].append(tok)
    return pila[0][0]  # el (module ...)


# --------------------------------------------------------------------------- #
# 2. Codificación de números y tipos
# --------------------------------------------------------------------------- #

def u(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def s(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if (n == 0 and not (b & 0x40)) or (n == -1 and (b & 0x40)):
            out.append(b)
            return bytes(out)
        out.append(b | 0x80)


def _entero(texto: str) -> int:
    texto = texto.replace("_", "")
    negativo = texto.startswith("-")
    if negativo:
        texto = texto[1:]
    base = 16 if texto.lower().startswith("0x") else 10
    valor = int(texto, base)
    return -valor if negativo else valor


def _const_i32(texto: str) -> bytes:
    v = _entero(texto)
    if v >= 0x80000000:
        v -= 0x100000000
    return s(v)


def _const_i64(texto: str) -> bytes:
    v = _entero(texto)
    if v >= 0x8000000000000000:
        v -= 0x10000000000000000
    return s(v)


def _const_f64(texto: str) -> bytes:
    t = texto.lower()
    if t in ("inf", "+inf"):
        x = float("inf")
    elif t == "-inf":
        x = float("-inf")
    elif t.startswith("nan"):
        x = float("nan")
    elif t.startswith("0x") or t.startswith("-0x"):
        x = float.fromhex(texto)
    else:
        x = float(texto)
    return struct.pack("<d", x)


_HEAP = {"any": 0x6E, "eq": 0x6D, "i31": 0x6C, "struct": 0x6B, "array": 0x6A,
         "none": 0x65, "func": 0x70, "nofunc": 0x73, "extern": 0x6F,
         "noextern": 0x69}

_VALTIPO = {"i32": b"\x7f", "i64": b"\x7e", "f32": b"\x7d", "f64": b"\x7c",
            "anyref": b"\x6e", "eqref": b"\x6d", "i31ref": b"\x6c",
            "structref": b"\x6b", "arrayref": b"\x6a", "funcref": b"\x70",
            "externref": b"\x6f", "nullref": b"\x65"}


class Modulo:
    """Estado del ensamblado: tablas de nombres a índices."""

    def __init__(self):
        self.tipos: dict[str, int] = {}          # nombre -> índice de tipo
        self.campos: dict[str, dict[str, int]] = {}  # tipo -> {campo: índice}
        self.funcs: dict[str, int] = {}          # nombre -> índice de función
        self.globales: dict[str, int] = {}       # nombre -> índice
        self.datos: dict[str, int] = {}          # nombre -> índice de segmento


def heaptipo(ht: str, mod: Modulo) -> bytes:
    if ht in _HEAP:
        return bytes([_HEAP[ht]])
    return s(mod.tipos[ht])  # índice de tipo concreto, como s33


def valtipo(nodo, mod: Modulo) -> bytes:
    if isinstance(nodo, str):
        return _VALTIPO[nodo]
    # (ref $T) / (ref null $T) / (ref i31) ...
    resto = nodo[1:]
    if resto[0] == "null":
        return b"\x63" + heaptipo(resto[1], mod)
    return b"\x64" + heaptipo(resto[0], mod)


def almacentipo(nodo, mod: Modulo) -> bytes:
    if nodo == "i8":
        return b"\x78"
    if nodo == "i16":
        return b"\x77"
    return valtipo(nodo, mod)


def campotipo(nodo, mod: Modulo) -> bytes:
    """(mut T) o T  ->  storagetype + byte de mutabilidad."""
    if isinstance(nodo, list) and nodo[0] == "mut":
        return almacentipo(nodo[1], mod) + b"\x01"
    return almacentipo(nodo, mod) + b"\x00"


# --------------------------------------------------------------------------- #
# 3. Opcodes
# --------------------------------------------------------------------------- #

_OP = {
    # control y variables
    "unreachable": b"\x00", "nop": b"\x01", "return": b"\x0f", "call": b"\x10",
    "drop": b"\x1a", "select": b"\x1b",
    "local.get": b"\x20", "local.set": b"\x21", "local.tee": b"\x22",
    "global.get": b"\x23", "global.set": b"\x24",
    "br": b"\x0c", "br_if": b"\x0d",
    # memoria
    "i32.load": b"\x28", "i64.load": b"\x29", "f64.load": b"\x2b",
    "i32.load8_s": b"\x2c", "i32.load8_u": b"\x2d",
    "i32.load16_s": b"\x2e", "i32.load16_u": b"\x2f",
    "i32.store": b"\x36", "i64.store": b"\x37", "f64.store": b"\x39",
    "i32.store8": b"\x3a", "i32.store16": b"\x3b",
    "memory.size": b"\x3f", "memory.grow": b"\x40",
    # constantes
    "i32.const": b"\x41", "i64.const": b"\x42", "f64.const": b"\x44",
    # comparaciones i32
    "i32.eqz": b"\x45", "i32.eq": b"\x46", "i32.ne": b"\x47",
    "i32.lt_s": b"\x48", "i32.lt_u": b"\x49", "i32.gt_s": b"\x4a",
    "i32.gt_u": b"\x4b", "i32.le_s": b"\x4c", "i32.le_u": b"\x4d",
    "i32.ge_s": b"\x4e", "i32.ge_u": b"\x4f",
    # comparaciones i64
    "i64.eqz": b"\x50", "i64.eq": b"\x51", "i64.ne": b"\x52",
    "i64.lt_s": b"\x53", "i64.lt_u": b"\x54", "i64.gt_s": b"\x55",
    "i64.gt_u": b"\x56", "i64.le_s": b"\x57", "i64.le_u": b"\x58",
    "i64.ge_s": b"\x59", "i64.ge_u": b"\x5a",
    # comparaciones f64
    "f64.eq": b"\x61", "f64.ne": b"\x62", "f64.lt": b"\x63", "f64.gt": b"\x64",
    "f64.le": b"\x65", "f64.ge": b"\x66",
    # aritmética i32
    "i32.add": b"\x6a", "i32.sub": b"\x6b", "i32.mul": b"\x6c",
    "i32.div_s": b"\x6d", "i32.div_u": b"\x6e", "i32.rem_s": b"\x6f",
    "i32.rem_u": b"\x70", "i32.and": b"\x71", "i32.or": b"\x72",
    "i32.xor": b"\x73", "i32.shl": b"\x74", "i32.shr_s": b"\x75",
    "i32.shr_u": b"\x76", "i32.rotl": b"\x77", "i32.rotr": b"\x78",
    # aritmética i64
    "i64.add": b"\x7c", "i64.sub": b"\x7d", "i64.mul": b"\x7e",
    "i64.div_s": b"\x7f", "i64.div_u": b"\x80", "i64.rem_s": b"\x81",
    "i64.rem_u": b"\x82", "i64.and": b"\x83", "i64.or": b"\x84",
    "i64.xor": b"\x85", "i64.shl": b"\x86", "i64.shr_s": b"\x87",
    "i64.shr_u": b"\x88", "i64.rotl": b"\x89", "i64.rotr": b"\x8a",
    # aritmética f64
    "f64.abs": b"\x99", "f64.neg": b"\x9a", "f64.ceil": b"\x9b",
    "f64.floor": b"\x9c", "f64.trunc": b"\x9d", "f64.nearest": b"\x9e",
    "f64.sqrt": b"\x9f", "f64.add": b"\xa0", "f64.sub": b"\xa1",
    "f64.mul": b"\xa2", "f64.div": b"\xa3", "f64.min": b"\xa4",
    "f64.max": b"\xa5", "f64.copysign": b"\xa6",
    # conversiones
    "i32.wrap_i64": b"\xa7", "i32.trunc_f64_s": b"\xaa", "i32.trunc_f64_u": b"\xab",
    "i64.extend_i32_s": b"\xac", "i64.extend_i32_u": b"\xad",
    "f64.convert_i32_s": b"\xb7", "f64.convert_i32_u": b"\xb8",
    "f64.convert_i64_s": b"\xb9", "f64.convert_i64_u": b"\xba",
    "f64.promote_f32": b"\xbb",
    "i32.reinterpret_f32": b"\xbc", "i64.reinterpret_f64": b"\xbd",
    "f64.reinterpret_i64": b"\xbf",
    # referencias
    "ref.null": b"\xd0", "ref.is_null": b"\xd1", "ref.func": b"\xd2",
    "ref.eq": b"\xd3", "ref.as_non_null": b"\xd4",
    # GC (prefijo 0xFB)
    "struct.new": b"\xfb\x00", "struct.new_default": b"\xfb\x01",
    "struct.get": b"\xfb\x02", "struct.get_s": b"\xfb\x03",
    "struct.get_u": b"\xfb\x04", "struct.set": b"\xfb\x05",
    "array.new": b"\xfb\x06", "array.new_default": b"\xfb\x07",
    "array.new_fixed": b"\xfb\x08", "array.new_data": b"\xfb\x09",
    "array.get": b"\xfb\x0b", "array.get_s": b"\xfb\x0c",
    "array.get_u": b"\xfb\x0d", "array.set": b"\xfb\x0e",
    "array.len": b"\xfb\x0f", "array.fill": b"\xfb\x10",
    "array.copy": b"\xfb\x11",
    "ref.i31": b"\xfb\x1c", "i31.get_s": b"\xfb\x1d", "i31.get_u": b"\xfb\x1e",
}

# alineación natural (log2) para los accesos a memoria
_ALINEA = {"i32.load": 2, "i32.store": 2, "i64.load": 3, "i64.store": 3,
           "f64.load": 3, "f64.store": 3, "i32.load8_s": 0, "i32.load8_u": 0,
           "i32.store8": 0, "i32.load16_s": 1, "i32.load16_u": 1,
           "i32.store16": 1}


# --------------------------------------------------------------------------- #
# 4. Bajada de instrucciones (folded -> lineal)
# --------------------------------------------------------------------------- #

class Contexto:
    def __init__(self, mod: Modulo, locales: dict[str, int]):
        self.mod = mod
        self.locales = locales
        self.etiquetas: list[str | None] = []


def _blocktype(args, idx, ctx):
    if idx < len(args) and isinstance(args[idx], list) and args[idx][0] == "result":
        return valtipo(args[idx][1], ctx.mod), idx + 1
    if idx < len(args) and isinstance(args[idx], list) and args[idx][0] == "param":
        raise ValueError("blocktype con parámetros no soportado")
    return b"\x40", idx


def _label(ctx, nombre):
    for prof, lbl in enumerate(reversed(ctx.etiquetas)):
        if lbl == nombre:
            return prof
    raise KeyError(f"etiqueta desconocida: {nombre}")


def bajar(nodo, ctx: Contexto, out: bytearray):
    cabeza = nodo[0]
    args = nodo[1:]

    if cabeza in ("block", "loop"):
        idx = 0
        etiqueta = None
        if args and isinstance(args[0], str) and args[0].startswith("$"):
            etiqueta = args[0]
            idx = 1
        bt, idx = _blocktype(args, idx, ctx)
        out.append(0x02 if cabeza == "block" else 0x03)
        out += bt
        ctx.etiquetas.append(etiqueta)
        for a in args[idx:]:
            bajar(a, ctx, out)
        ctx.etiquetas.pop()
        out.append(0x0B)
        return

    if cabeza == "if":
        idx = 0
        etiqueta = None
        if args and isinstance(args[0], str) and args[0].startswith("$"):
            etiqueta = args[0]
            idx = 1
        bt, idx = _blocktype(args, idx, ctx)
        cond, entonces, sino = [], None, None
        for a in args[idx:]:
            if isinstance(a, list) and a and a[0] == "then":
                entonces = a
            elif isinstance(a, list) and a and a[0] == "else":
                sino = a
            else:
                cond.append(a)
        for c in cond:
            bajar(c, ctx, out)
        out.append(0x04)
        out += bt
        ctx.etiquetas.append(etiqueta)
        for a in entonces[1:]:
            bajar(a, ctx, out)
        if sino is not None:
            out.append(0x05)
            for a in sino[1:]:
                bajar(a, ctx, out)
        ctx.etiquetas.pop()
        out.append(0x0B)
        return

    if cabeza in ("ref.test", "ref.cast"):
        rt = args[0]
        nulo = len(rt) > 2 and rt[1] == "null"
        ht = rt[-1]
        for op in args[1:]:
            bajar(op, ctx, out)
        sub = {("ref.test", False): 0x14, ("ref.test", True): 0x15,
               ("ref.cast", False): 0x16, ("ref.cast", True): 0x17}[(cabeza, nulo)]
        out += b"\xfb" + u(sub) + heaptipo(ht, ctx.mod)
        return

    imm, operandos = _inmediatos(cabeza, args, ctx)
    for op in operandos:
        bajar(op, ctx, out)
    out += _OP[cabeza]
    out += imm


def _inmediatos(cabeza, args, ctx):
    mod = ctx.mod
    if cabeza == "i32.const":
        return _const_i32(args[0]), args[1:]
    if cabeza == "i64.const":
        return _const_i64(args[0]), args[1:]
    if cabeza == "f64.const":
        return _const_f64(args[0]), args[1:]
    if cabeza in ("local.get", "local.set", "local.tee"):
        return u(ctx.locales[args[0]]), args[1:]
    if cabeza in ("global.get", "global.set"):
        return u(mod.globales[args[0]]), args[1:]
    if cabeza == "call":
        return u(mod.funcs[args[0]]), args[1:]
    if cabeza in ("br", "br_if"):
        return u(_label(ctx, args[0])), args[1:]
    if cabeza == "ref.null":
        return heaptipo(args[0], mod), args[1:]
    if cabeza in ("struct.new", "struct.new_default", "array.new",
                  "array.new_default", "array.get", "array.get_s",
                  "array.get_u", "array.set"):
        return u(mod.tipos[args[0]]), args[1:]
    if cabeza in ("struct.get", "struct.get_s", "struct.get_u", "struct.set"):
        return u(mod.tipos[args[0]]) + u(mod.campos[args[0]][args[1]]), args[2:]
    if cabeza == "array.new_fixed":
        return u(mod.tipos[args[0]]) + u(_entero(args[1])), args[2:]
    if cabeza == "array.new_data":
        return u(mod.tipos[args[0]]) + u(mod.datos[args[1]]), args[2:]
    if cabeza == "array.copy":
        return u(mod.tipos[args[0]]) + u(mod.tipos[args[1]]), args[2:]
    if cabeza in _ALINEA:
        return u(_ALINEA[cabeza]) + u(0), args
    if cabeza in ("memory.size", "memory.grow"):
        return b"\x00", args
    return b"", args


# --------------------------------------------------------------------------- #
# 5. Secciones y ensamblado del módulo
# --------------------------------------------------------------------------- #

def _vec(items) -> bytes:
    return u(len(items)) + b"".join(items)


def _seccion(ident, carga) -> bytes:
    return bytes([ident]) + u(len(carga)) + carga


def _firma(func_sexpr):
    """(params, results) como listas de nodos valtipo."""
    params, results = [], []
    for elem in func_sexpr:
        if isinstance(elem, list) and elem:
            if elem[0] == "param":
                # (param $n T) o (param T T ...)
                cola = elem[2:] if len(elem) > 1 and isinstance(elem[1], str) \
                    and elem[1].startswith("$") else elem[1:]
                params.extend(cola)
            elif elem[0] == "result":
                results.extend(elem[1:])
    return params, results


def ensamblar(wat: str) -> bytes:
    mod = Modulo()
    arbol = leer_sexpr(wat)
    campos = arbol[1:]  # tras 'module'

    # --- pasada 1: registrar tipos, funciones, globales, datos, memoria ---
    tipos_sexpr = []            # (nombre|None, sexpr del comptype)
    importes = []               # (mod, nombre, params, results)
    funcs = []                  # sexpr de cada func definida
    globales = []               # (mut, valtipo_nodo, init_nodo)
    datos = []                  # bytes de cada segmento
    exportes = []               # (nombre, tipo, indice)
    tiene_memoria = False

    for c in campos:
        clave = c[0]
        if clave == "type":
            nombre = c[1] if isinstance(c[1], str) and c[1].startswith("$") else None
            comptype = c[2] if nombre else c[1]
            idx = len(tipos_sexpr)
            if nombre:
                mod.tipos[nombre] = idx
            tipos_sexpr.append(comptype)
            if comptype[0] == "struct":
                campos_mapa = {}
                fidx = 0
                for f in comptype[1:]:
                    if isinstance(f, list) and f[0] == "field":
                        if len(f) > 1 and isinstance(f[1], str) and f[1].startswith("$"):
                            campos_mapa[f[1]] = fidx
                        fidx += 1
                if nombre:
                    mod.campos[nombre] = campos_mapa
        elif clave == "import":
            fn = c[3]
            nombre = fn[1] if isinstance(fn[1], str) and fn[1].startswith("$") else None
            params, results = _firma(fn[1:])
            if nombre:
                mod.funcs[nombre] = len([1 for _ in importes])
            importes.append((c[1].bytes, c[2].bytes, params, results))
        elif clave == "func":
            nombre = None
            j = 1
            if isinstance(c[1], str) and c[1].startswith("$"):
                nombre = c[1]
                j = 2
            idx = len(importes) + len(funcs)
            if nombre:
                mod.funcs[nombre] = idx
            for elem in c[j:]:
                if isinstance(elem, list) and elem and elem[0] == "export":
                    exportes.append((elem[1].bytes, 0x00, idx))
            funcs.append(c)
        elif clave == "memory":
            tiene_memoria = True
            for elem in c[1:]:
                if isinstance(elem, list) and elem and elem[0] == "export":
                    exportes.append((elem[1].bytes, 0x02, 0))
        elif clave == "global":
            nombre = None
            j = 1
            if isinstance(c[1], str) and c[1].startswith("$"):
                nombre = c[1]
                j = 2
            mod.globales[nombre] = len(globales)
            gt = c[j]
            init = c[j + 1]
            if isinstance(gt, list) and gt[0] == "mut":
                globales.append((1, gt[1], init))
            else:
                globales.append((0, gt, init))
        elif clave == "data":
            nombre = c[1] if isinstance(c[1], str) and c[1].startswith("$") else None
            contenido = c[-1]
            octetos = contenido.bytes if isinstance(contenido, Cadena) else b""
            if nombre:
                mod.datos[nombre] = len(datos)
            datos.append(octetos)
        elif clave == "export":
            # export de nivel superior: (export "n" (func $x)) / (memory ...)
            objetivo = c[2]
            tipo = {"func": 0x00, "memory": 0x02, "global": 0x03}[objetivo[0]]
            if objetivo[0] == "memory":
                exportes.append((c[1].bytes, 0x02, 0))
            elif objetivo[0] == "func":
                exportes.append((c[1].bytes, 0x00, mod.funcs[objetivo[1]]))
            elif objetivo[0] == "global":
                exportes.append((c[1].bytes, 0x03, mod.globales[objetivo[1]]))

    # --- tipos de función: deduplicar firmas (importes + definidas) ---
    firmas = []
    clave_firma = {}

    def indice_firma(params, results):
        cuerpo = b"\x60" + _vec([valtipo(p, mod) for p in params]) + \
            _vec([valtipo(r, mod) for r in results])
        if cuerpo not in clave_firma:
            clave_firma[cuerpo] = len(tipos_sexpr) + len(firmas)
            firmas.append(cuerpo)
        return clave_firma[cuerpo]

    idx_importes = [indice_firma(p, r) for (_, _, p, r) in importes]
    idx_funcs = []
    for c in funcs:
        j = 2 if (isinstance(c[1], str) and c[1].startswith("$")) else 1
        p, r = _firma(c[j:])
        idx_funcs.append(indice_firma(p, r))

    # --- sección de tipos ---
    entradas_tipo = []
    for comptype in tipos_sexpr:
        if comptype[0] == "struct":
            campos_bytes = []
            for f in comptype[1:]:
                if isinstance(f, list) and f[0] == "field":
                    tipo_nodo = f[2] if (len(f) > 1 and isinstance(f[1], str)
                                         and f[1].startswith("$")) else f[1]
                    campos_bytes.append(campotipo(tipo_nodo, mod))
            entradas_tipo.append(b"\x5f" + _vec(campos_bytes))
        elif comptype[0] == "array":
            entradas_tipo.append(b"\x5e" + campotipo(comptype[1], mod))
        else:
            raise ValueError(f"tipo no soportado: {comptype[0]}")
    entradas_tipo.extend(firmas)
    sec_tipos = _seccion(1, _vec(entradas_tipo))

    # --- sección de importes ---
    ents = []
    for (m, nom, p, r), ti in zip(importes, idx_importes):
        ents.append(u(len(m)) + m + u(len(nom)) + nom + b"\x00" + u(ti))
    sec_import = _seccion(2, _vec(ents)) if ents else b""

    # --- sección de funciones ---
    sec_func = _seccion(3, _vec([u(ti) for ti in idx_funcs]))

    # --- sección de memoria ---
    sec_mem = _seccion(5, _vec([b"\x00" + u(1)])) if tiene_memoria else b""

    # --- sección de globales ---
    ents = []
    for mut, tipo_nodo, init in globales:
        cuerpo = bytearray()
        bajar(init, Contexto(mod, {}), cuerpo)
        cuerpo.append(0x0B)
        ents.append(valtipo(tipo_nodo, mod) + bytes([mut]) + bytes(cuerpo))
    sec_global = _seccion(6, _vec(ents)) if ents else b""

    # --- sección de exportes ---
    ents = []
    for nom, tipo, idx in exportes:
        ents.append(u(len(nom)) + nom + bytes([tipo]) + u(idx))
    sec_export = _seccion(7, _vec(ents)) if ents else b""

    # --- DataCount (obligatoria por array.new_data) ---
    sec_datacount = _seccion(12, u(len(datos))) if datos else b""

    # --- sección de código ---
    cuerpos = []
    for c in funcs:
        j = 2 if (isinstance(c[1], str) and c[1].startswith("$")) else 1
        params_nombres = {}
        pos = 0
        locales_tipos = []
        locales_nombres = {}
        instrucciones = []
        for elem in c[j:]:
            if isinstance(elem, list) and elem and elem[0] == "param":
                if len(elem) > 1 and isinstance(elem[1], str) and elem[1].startswith("$"):
                    params_nombres[elem[1]] = pos
                    pos += 1
                else:
                    pos += len(elem) - 1
            elif isinstance(elem, list) and elem and elem[0] == "result":
                pass
            elif isinstance(elem, list) and elem and elem[0] == "local":
                if len(elem) > 1 and isinstance(elem[1], str) and elem[1].startswith("$"):
                    locales_nombres[elem[1]] = len(params_nombres) + len(locales_tipos)
                    locales_tipos.append(elem[2])
                else:
                    for t in elem[1:]:
                        locales_tipos.append(t)
            elif isinstance(elem, list) and elem and elem[0] == "export":
                pass
            else:
                instrucciones.append(elem)
        mapa_locales = dict(params_nombres)
        mapa_locales.update(locales_nombres)
        ctx = Contexto(mod, mapa_locales)
        cuerpo = bytearray()
        for ins in instrucciones:
            bajar(ins, ctx, cuerpo)
        cuerpo.append(0x0B)
        # locales agrupadas por tipo consecutivo
        grupos = []
        for t in locales_tipos:
            vt = valtipo(t, mod)
            if grupos and grupos[-1][1] == vt:
                grupos[-1][0] += 1
            else:
                grupos.append([1, vt])
        locales_bin = _vec([u(n) + vt for n, vt in grupos])
        entrada = locales_bin + bytes(cuerpo)
        cuerpos.append(u(len(entrada)) + entrada)
    sec_code = _seccion(10, _vec(cuerpos))

    # --- sección de datos (todos pasivos) ---
    ents = [b"\x01" + u(len(d)) + d for d in datos]
    sec_data = _seccion(11, _vec(ents)) if ents else b""

    return (b"\x00asm\x01\x00\x00\x00" + sec_tipos + sec_import + sec_func +
            sec_mem + sec_global + sec_export + sec_datacount + sec_code +
            sec_data)
