"""Permite ejecutar el intérprete con `python -m anlaco`."""

import sys

from anlaco.cli import main

sys.exit(main())
