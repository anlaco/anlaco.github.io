"""Compilador de Anlaco a WebAssembly (fase 2).

Genera texto WAT (el formato legible de WebAssembly), que wasmtime ejecuta
directamente:

    anlaco compilar programa.ana
    wasmtime run --dir . -W function-references=y,gc=y programa.wat

Decisiones de la fase 2 (2026-07-08, con el usuario):
- WasmGC: los valores viven como objetos que el propio motor recicla; la
  memoria lineal queda solo para la frontera WASI (imprimir, leer).
- Enteros ilimitados (bignum) desde el primer día, fieles a la espec: arrays
  de limbs de 32 bits. Nada de desbordamientos silenciosos.

Representación de los valores: entero = struct con signo y limbs; decimal =
struct con f64; texto = array de bytes UTF-8; booleano = i31 (0/1); nada =
null. El tiempo de ejecución (bignum, mostrar, igualdad) vive en
preludio.wat; este módulo lo envuelve y emite el programa sobre él. Lo que
aún no sabe compilar da un error claro que remite al intérprete.

Huecos conocidos frente al intérprete (se cierran con los ejemplos que van
quedando): los errores de tipos en operaciones matemáticas salen como trampa
de WASM en vez de mensaje amable, y un entero gigantesco convertido a
decimal (o un decimal tecleado) puede redondear distinto que Python en el
último bit.
"""

from __future__ import annotations

from pathlib import Path

from . import ast_nodes as ast
from .errors import error, mensaje
from .lexer import detectar_idioma
from .parser import parse

_OPERACIONES = {"+": "$num_suma", "-": "$num_resta",
                "*": "$num_multiplica", "/": "$num_divide"}
_COMPARADORES = {">": "i32.gt_s", "<": "i32.lt_s", ">=": "i32.ge_s", "<=": "i32.le_s"}


def compilar(fuente: str, idioma: str | None = None) -> str:
    """El programa convertido a WAT, listo para wasmtime."""
    idioma = idioma or detectar_idioma(fuente)
    programa = parse(fuente, idioma)
    return Compilador(idioma).programa(programa)


def _escapar_wat(datos: bytes) -> str:
    """Los bytes como cadena de datos WAT: UTF-8 con escapes \\XX en hex."""
    trozos = []
    for byte in datos:
        if byte in (0x22, 0x5C):  # comillas y barra invertida
            trozos.append("\\" + chr(byte))
        elif 0x20 <= byte < 0x7F:
            trozos.append(chr(byte))
        else:
            trozos.append(f"\\{byte:02x}")
    return "".join(trozos)


def _preludio(idioma: str) -> str:
    """El tiempo de ejecución, con sus mensajes de error en el idioma del programa."""
    plantilla = (Path(__file__).parent / "preludio.wat").read_text("utf-8")
    prefijo = mensaje(idioma, "general.error")
    # los mensajes con {valor} se parten en dos: el valor se pone en ejecución
    cond_pre, cond_post = _plantilla_partida(idioma, "interprete.condicion_booleana")
    entero_pre, entero_post = _plantilla_partida(idioma, "interprete.entero_esperado")
    lista_pre, lista_post = _plantilla_partida(idioma, "interprete.lista_esperada")
    anade_pre, anade_post = _plantilla_partida(idioma, "interprete.anade_destino")
    # indice_fuera tiene dos huecos: {cantidad} ... {indice}
    indice_pre, resto = _plantilla_partida(idioma, "interprete.indice_fuera", "{cantidad}")
    indice_mid, indice_post = resto.split("{indice}")
    azar_pre, resto = _plantilla_partida(idioma, "interprete.azar_orden", "{desde}")
    azar_mid, azar_post = resto.split("{hasta}")
    texto_pre, texto_post = _plantilla_partida(idioma, "interprete.texto_esperado")
    archivo_pre, archivo_post = _plantilla_partida(
        idioma, "interprete.archivo_no_encontrado", "{ruta}")
    segmentos = {
        "div0": f"{prefijo} {mensaje(idioma, 'interprete.division_cero')}",
        "cond_pre": f"{prefijo} {cond_pre}",
        "cond_post": cond_post,
        "entero_pre": f"{prefijo} {entero_pre}",
        "entero_post": entero_post,
        "verdadero": mensaje(idioma, "literales.verdadero"),
        "falso": mensaje(idioma, "literales.falso"),
        "nada": mensaje(idioma, "literales.nada"),
        "sin_respuesta": f"{prefijo} {mensaje(idioma, 'interprete.sin_respuesta')}",
        "llamadas": f"{prefijo} "
                    f"{mensaje(idioma, 'interprete.demasiadas_llamadas', maximo=1000)}",
        "lista_pre": f"{prefijo} {lista_pre}",
        "lista_post": lista_post,
        "anade_pre": f"{prefijo} {anade_pre}",
        "anade_post": anade_post,
        "indice_pre": f"{prefijo} {indice_pre}",
        "indice_mid": indice_mid,
        "indice_post": indice_post,
        "vacia_primero": f"{prefijo} {mensaje(idioma, 'interprete.lista_vacia_primero')}",
        "vacia_ultimo": f"{prefijo} {mensaje(idioma, 'interprete.lista_vacia_ultimo')}",
        "azar_pre": f"{prefijo} {azar_pre}",
        "azar_mid": azar_mid,
        "azar_post": azar_post,
        "texto_pre": f"{prefijo} {texto_pre}",
        "texto_post": texto_post,
        "archivo_pre": f"{prefijo} {archivo_pre}",
        "archivo_post": archivo_post,
    }
    for nombre, texto in segmentos.items():
        datos = texto.encode("utf-8")
        plantilla = (plantilla
                     .replace('"{msg_%s}"' % nombre, f'"{_escapar_wat(datos)}"')
                     .replace("{msg_%s_len}" % nombre, str(len(datos))))
    return plantilla


def _plantilla_partida(idioma: str, clave: str, hueco: str = "{valor}") -> tuple[str, str]:
    seccion, nombre = clave.split(".")
    import tomllib
    ruta = Path(__file__).parent / "mensajes" / f"{idioma}.toml"
    if not ruta.exists():
        ruta = Path(__file__).parent / "mensajes" / "es.toml"
    plantilla = tomllib.loads(ruta.read_text("utf-8"))[seccion][nombre]
    antes, _, despues = plantilla.partition(hueco)
    return antes, despues


def _limpio(nombre: str) -> str:
    return "".join(c if c.isascii() and (c.isalnum() or c == "_") else "_" for c in nombre)


def _asignados(sentencias: list[ast.Nodo]) -> list[str]:
    """Los nombres que este cuerpo asigna (en una función se vuelven locales)."""
    nombres: list[str] = []

    def recorre(lista):
        for nodo in lista:
            if isinstance(nodo, ast.Asigna):
                nombres.append(nodo.nombre)
            elif isinstance(nodo, (ast.ParaCadaEnRango, ast.ParaCadaEnLista)):
                nombres.append(nodo.variable)
                recorre(nodo.cuerpo)
            elif isinstance(nodo, ast.Si):
                recorre(nodo.entonces)
                if nodo.sino is not None:
                    recorre(nodo.sino)
            elif isinstance(nodo, (ast.Mientras, ast.Repite)):
                recorre(nodo.cuerpo)

    recorre(sentencias)
    return list(dict.fromkeys(nombres))


class Compilador:
    def __init__(self, idioma: str):
        self.idioma = idioma
        self.datos: list[bytes] = []          # segmentos de datos, uno por literal
        self.variables: dict[str, str] = {}   # variable global -> identificador WAT
        self.locales: list[str] = []          # locales del func en curso (o _start)
        self.bucles = 0                       # para etiquetas únicas
        self.funciones: dict[str, tuple[str, list[str]]] = {}
        self.ambito: dict[str, str] | None = None  # locales visibles (None = programa)
        self.globales_asignadas: set[str] = set()

    def programa(self, programa: ast.Programa) -> str:
        definiciones = [s for s in programa.sentencias if isinstance(s, ast.Define)]
        principales = [s for s in programa.sentencias if not isinstance(s, ast.Define)]
        # primera pasada: las funciones se conocen enteras antes de compilar nada
        for numero, definicion in enumerate(definiciones):
            self.funciones[definicion.nombre] = (
                f"$f{numero}_{_limpio(definicion.nombre)}", definicion.parametros)
        self.globales_asignadas = set(_asignados(principales))
        funciones = [self._funcion(d) for d in definiciones]
        cuerpo = []
        for sentencia in principales:
            cuerpo.extend(self.sentencia(sentencia))
        lineas = ["(module", _preludio(self.idioma), ";; --- el programa ---", ""]
        for numero, datos in enumerate(self.datos):
            lineas.append(f'(data $datos{numero} "{_escapar_wat(datos)}")')
        for nombre, identificador in self.variables.items():
            lineas.append(f"(global {identificador} (mut anyref) (ref.null any)) ;; {nombre}")
        for funcion in funciones:
            lineas.extend(funcion)
        lineas.append('(func (export "_start")')
        lineas.extend(f"  (local {temporal})" for temporal in self.locales)
        lineas.extend(f"  {linea}" for linea in cuerpo)
        lineas.append(")")
        lineas.append(")")
        return "\n".join(lineas) + "\n"

    def _funcion(self, nodo: ast.Define) -> list[str]:
        identificador, parametros = self.funciones[nodo.nombre]
        exteriores = (self.locales, self.ambito)
        self.locales = []
        self.ambito = {parametro: f"$p{i}_{_limpio(parametro)}"
                       for i, parametro in enumerate(parametros)}
        # lo que la función asigna son variables locales (espec §6)
        for nombre in _asignados(nodo.cuerpo):
            if nombre not in self.ambito:
                local = f"$l{len(self.locales)}_{_limpio(nombre)}"
                self.ambito[nombre] = local
                self.locales.append(f"{local} anyref")
        cuerpo = self.bloque(nodo.cuerpo)
        lineas = [f"(func {identificador}"
                  + "".join(f" (param {self.ambito[p]} anyref)" for p in parametros)
                  + " (result anyref)"]
        lineas += [f"  (local {temporal})" for temporal in self.locales]
        lineas.append("  (call $entra_llamada)")
        lineas += [f"  {linea}" for linea in cuerpo]
        # el final sin devuelve: la función vale nada
        lineas.append("  (call $sale_llamada)")
        lineas.append("  (ref.null any)")
        lineas.append(")")
        self.locales, self.ambito = exteriores
        return lineas

    # --- sentencias (cada una es una lista de líneas WAT) ---

    def sentencia(self, nodo: ast.Nodo) -> list[str]:
        if isinstance(nodo, ast.Escribe):
            return [f"(call $escribe (call $mostrar {self.expresion(nodo.expresion)}))"]
        if isinstance(nodo, ast.Asigna):
            return [f"({self._sitio(nodo.nombre)[0]}.set {self._sitio(nodo.nombre)[1]} "
                    f"{self.expresion(nodo.expresion)})"]
        if isinstance(nodo, ast.Devuelve):
            if self.ambito is None:
                raise error(self.idioma, "interprete.devuelve_fuera", nodo.linea)
            if nodo.expresion is None:
                return ["(call $sale_llamada)", "(return (ref.null any))"]
            # el valor se calcula ANTES de salir: si llama a otra función,
            # esa llamada aún cuenta dentro de esta profundidad
            temporal = self._local()
            return [f"(local.set {temporal} {self.expresion(nodo.expresion)})",
                    "(call $sale_llamada)",
                    f"(return (local.get {temporal}))"]
        if isinstance(nodo, ast.Si):
            return self._si(nodo)
        if isinstance(nodo, ast.Mientras):
            return self._mientras(nodo)
        if isinstance(nodo, ast.Repite):
            return self._repite(nodo)
        if isinstance(nodo, ast.ParaCadaEnRango):
            return self._rango(nodo)
        if isinstance(nodo, ast.ParaCadaEnLista):
            return self._para_cada_lista(nodo)
        if isinstance(nodo, ast.Anade):
            return [f"(call $anade {self.expresion(nodo.valor)} "
                    f"{self.expresion(nodo.destino)})"]
        if isinstance(nodo, ast.Guarda):
            return [f"(call $guarda {self.expresion(nodo.valor)} "
                    f"{self.expresion(nodo.ruta)})"]
        raise self._aun_no(nodo)

    def bloque(self, sentencias: list[ast.Nodo]) -> list[str]:
        return [linea for sentencia in sentencias for linea in self.sentencia(sentencia)]

    def _si(self, nodo: ast.Si) -> list[str]:
        lineas = [f"(if (call $verdad {self.expresion(nodo.condicion)})", "  (then"]
        lineas += ["    " + linea for linea in self.bloque(nodo.entonces)]
        lineas.append("  )")
        if nodo.sino is not None:
            lineas.append("  (else")
            lineas += ["    " + linea for linea in self.bloque(nodo.sino)]
            lineas.append("  )")
        lineas.append(")")
        return lineas

    def _mientras(self, nodo: ast.Mientras) -> list[str]:
        numero = self._bucle()
        lineas = [f"(block $fuera{numero}", f"  (loop $bucle{numero}",
                  f"    (br_if $fuera{numero} "
                  f"(i32.eqz (call $verdad {self.expresion(nodo.condicion)})))"]
        lineas += ["    " + linea for linea in self.bloque(nodo.cuerpo)]
        lineas.append(f"    (br $bucle{numero})))")
        return lineas

    def _repite(self, nodo: ast.Repite) -> list[str]:
        numero = self._bucle()
        contador = self._local()
        lineas = [f"(local.set {contador} (call $a_entero {self.expresion(nodo.veces)}))",
                  f"(block $fuera{numero}", f"  (loop $bucle{numero}",
                  f"    (br_if $fuera{numero} "
                  f"(i32.eqz (call $es_positivo (local.get {contador}))))"]
        lineas += ["    " + linea for linea in self.bloque(nodo.cuerpo)]
        lineas.append(f"    (local.set {contador} "
                      f"(call $num_resta (local.get {contador}) (call $uno)))")
        lineas.append(f"    (br $bucle{numero})))")
        return lineas

    def _rango(self, nodo: ast.ParaCadaEnRango) -> list[str]:
        numero = self._bucle()
        indice = self._local()
        tope = self._local()
        donde, variable = self._sitio(nodo.variable)
        lineas = [f"(local.set {indice} (call $a_entero {self.expresion(nodo.desde)}))",
                  f"(local.set {tope} (call $a_entero {self.expresion(nodo.hasta)}))",
                  f"(block $fuera{numero}", f"  (loop $bucle{numero}",
                  f"    (br_if $fuera{numero} (i32.gt_s (call $num_compara "
                  f"(local.get {indice}) (local.get {tope})) (i32.const 0)))",
                  f"    ({donde}.set {variable} (local.get {indice}))"]
        lineas += ["    " + linea for linea in self.bloque(nodo.cuerpo)]
        lineas.append(f"    (local.set {indice} "
                      f"(call $num_suma (local.get {indice}) (call $uno)))")
        lineas.append(f"    (br $bucle{numero})))")
        return lineas

    def _para_cada_lista(self, nodo: ast.ParaCadaEnLista) -> list[str]:
        numero = self._bucle()
        lista = self._local("(ref null $Lista)")
        indice = self._local("i32")
        donde, variable = self._sitio(nodo.variable)
        # el largo se mira en cada vuelta: añadir dentro del bucle alarga el paseo
        lineas = [f"(local.set {lista} (call $a_lista {self.expresion(nodo.lista)}))",
                  f"(local.set {indice} (i32.const 0))",
                  f"(block $fuera{numero}", f"  (loop $bucle{numero}",
                  f"    (br_if $fuera{numero} (i32.ge_s (local.get {indice}) "
                  f"(struct.get $Lista $n (local.get {lista}))))",
                  f"    ({donde}.set {variable} (array.get $Items "
                  f"(struct.get $Lista $items (local.get {lista})) (local.get {indice})))"]
        lineas += ["    " + linea for linea in self.bloque(nodo.cuerpo)]
        lineas.append(f"    (local.set {indice} (i32.add (local.get {indice}) (i32.const 1)))")
        lineas.append(f"    (br $bucle{numero})))")
        return lineas

    # --- expresiones (cada una es un término WAT plegado) ---

    def expresion(self, nodo: ast.Nodo) -> str:
        if isinstance(nodo, ast.Numero):
            return self._numero(nodo.valor)
        if isinstance(nodo, ast.Texto):
            return self._texto(nodo)
        if isinstance(nodo, ast.Booleano):
            return f"(ref.i31 (i32.const {int(nodo.valor)}))"
        if isinstance(nodo, ast.Nada):
            return "(ref.null any)"
        if isinstance(nodo, ast.Nombre):
            return self._nombre(nodo)
        if isinstance(nodo, ast.Llamada):
            return self._llamada(nodo)
        if isinstance(nodo, ast.Binaria):
            return self._binaria(nodo)
        if isinstance(nodo, ast.MenosUnario):
            return f"(call $num_negado {self.expresion(nodo.expresion)})"
        if isinstance(nodo, ast.RespuestaA):
            return f"(call $respuesta {self.expresion(nodo.pregunta)})"
        if isinstance(nodo, ast.Lista):
            resultado = "(call $lista_nueva)"
            for elemento in nodo.elementos:
                resultado = f"(call $lista_anade {resultado} {self.expresion(elemento)})"
            return resultado
        if isinstance(nodo, ast.ElementoDe):
            return (f"(call $lista_elemento {self.expresion(nodo.coleccion)} "
                    f"{self.expresion(nodo.indice)})")
        if isinstance(nodo, ast.PrimeroDe):
            return f"(call $lista_primero {self.expresion(nodo.coleccion)})"
        if isinstance(nodo, ast.UltimoDe):
            return f"(call $lista_ultimo {self.expresion(nodo.coleccion)})"
        if isinstance(nodo, ast.CantidadDe):
            return f"(call $lista_cantidad {self.expresion(nodo.coleccion)})"
        if isinstance(nodo, ast.ContenidoDe):
            return f"(call $contenido {self.expresion(nodo.ruta)})"
        if isinstance(nodo, ast.AlAzarEntre):
            return (f"(call $al_azar {self.expresion(nodo.desde)} "
                    f"{self.expresion(nodo.hasta)})")
        raise self._aun_no(nodo)

    def _binaria(self, nodo: ast.Binaria) -> str:
        izquierda = self.expresion(nodo.izquierda)
        derecha = self.expresion(nodo.derecha)
        if nodo.operador in _OPERACIONES:
            return f"(call {_OPERACIONES[nodo.operador]} {izquierda} {derecha})"
        if nodo.operador == "==":
            return f"(ref.i31 (call $iguales {izquierda} {derecha}))"
        if nodo.operador == "!=":
            return f"(ref.i31 (i32.eqz (call $iguales {izquierda} {derecha})))"
        if nodo.operador in _COMPARADORES:
            return (f"(ref.i31 ({_COMPARADORES[nodo.operador]} "
                    f"(call $num_compara {izquierda} {derecha}) (i32.const 0)))")
        # and / or: en corto, como el intérprete (el otro lado ni se evalúa)
        if nodo.operador == "and":
            return (f"(ref.i31 (if (result i32) (call $verdad {izquierda}) "
                    f"(then (call $verdad {derecha})) (else (i32.const 0))))")
        if nodo.operador == "or":
            return (f"(ref.i31 (if (result i32) (call $verdad {izquierda}) "
                    f"(then (i32.const 1)) (else (call $verdad {derecha}))))")
        raise self._aun_no(nodo)

    def _numero(self, valor: int | float) -> str:
        if isinstance(valor, float):
            # en hexadecimal el f64 queda exacto, bit a bit
            return f"(struct.new $Decimal (f64.const {valor.hex()}))"
        limbs = []
        magnitud = abs(valor)
        while magnitud:
            limbs.append(magnitud & 0xFFFFFFFF)
            magnitud >>= 32
        piezas = " ".join(
            f"(i32.const {limb - (1 << 32) if limb >= 1 << 31 else limb})"
            for limb in limbs)
        arreglo = f"(array.new_fixed $Limbs {len(limbs)}" + (f" {piezas})" if limbs else ")")
        return f"(struct.new $Entero (i32.const {int(valor < 0)}) {arreglo})"

    def _texto(self, nodo: ast.Texto) -> str:
        piezas = []
        for parte in nodo.partes:
            if isinstance(parte, str):
                if parte:  # los trozos vacíos no aportan nada
                    piezas.append(self._texto_literal(parte))
            else:
                piezas.append(f"(call $mostrar {self.expresion(parte)})")
        if not piezas:
            return self._texto_literal("")
        resultado = piezas[0]
        for pieza in piezas[1:]:
            resultado = f"(call $concatenar {resultado} {pieza})"
        return resultado

    def _texto_literal(self, texto: str) -> str:
        datos = texto.encode("utf-8")
        numero = len(self.datos)
        self.datos.append(datos)
        return (f"(array.new_data $Texto $datos{numero}"
                f" (i32.const 0) (i32.const {len(datos)}))")

    def _variable(self, nombre: str) -> str:
        if nombre not in self.variables:
            self.variables[nombre] = f"$v{len(self.variables)}_{_limpio(nombre)}"
        return self.variables[nombre]

    def _sitio(self, nombre: str) -> tuple[str, str]:
        """Dónde vive un nombre: local de la función en curso, o global."""
        if self.ambito is not None and nombre in self.ambito:
            return ("local", self.ambito[nombre])
        return ("global", self._variable(nombre))

    def _nombre(self, nodo: ast.Nombre) -> str:
        nombre = nodo.nombre
        if self.ambito is not None and nombre in self.ambito:
            return f"(local.get {self.ambito[nombre]})"
        # un nombre suelto que no es variable: función sin parámetros, se llama
        if nombre in self.funciones and nombre not in self.globales_asignadas:
            identificador, parametros = self.funciones[nombre]
            if parametros:
                raise error(self.idioma, "interprete.funcion_con_parametros",
                            nodo.linea, nombre=nombre)
            return f"(call {identificador})"
        return f"(global.get {self._variable(nombre)})"

    def _llamada(self, nodo: ast.Llamada) -> str:
        if nodo.nombre not in self.funciones:
            raise error(self.idioma, "interprete.funcion_desconocida",
                        nodo.linea, nombre=nodo.nombre)
        identificador, parametros = self.funciones[nodo.nombre]
        if len(nodo.argumentos) != len(parametros):
            raise error(self.idioma, "interprete.argumentos", nodo.linea,
                        nombre=nodo.nombre, espera=len(parametros),
                        parametros=", ".join(parametros) or "-",
                        llegan=len(nodo.argumentos))
        argumentos = " ".join(self.expresion(a) for a in nodo.argumentos)
        return f"(call {identificador}{' ' + argumentos if argumentos else ''})"

    def _local(self, tipo: str = "anyref") -> str:
        temporal = f"$t{len(self.locales)}"
        self.locales.append(f"{temporal} {tipo}")
        return temporal

    def _bucle(self) -> int:
        self.bucles += 1
        return self.bucles

    def _aun_no(self, nodo: ast.Nodo):
        return error(self.idioma, "compilador.aun_no", nodo.linea,
                     que=type(nodo).__name__)
