"""Línea de comandos de Anlaco.

Comandos disponibles (crecen con cada hito):
    anlaco ejecutar archivo.ana   ejecuta el programa
    anlaco arbol archivo.ana      muestra el árbol del programa
    anlaco fichas archivo.ana     muestra las fichas del lexer
"""

from __future__ import annotations

import sys
from dataclasses import fields
from pathlib import Path

from .ast_nodes import Nodo
from .errors import ErrorDeAnlaco, mensaje
from .interpreter import Interprete
from .lexer import detectar_idioma, tokenize
from .parser import parse


def presentar_error(error: ErrorDeAnlaco, fuente: str) -> str:
    """El formato de la especificación §8: línea señalada + mensaje amable."""
    if not error.linea:
        return f"{mensaje(error.idioma, 'general.error')} {error.mensaje}"
    lineas = fuente.splitlines()
    contenido = lineas[error.linea - 1].strip() if 1 <= error.linea <= len(lineas) else ""
    prefijo = mensaje(error.idioma, "general.error_con_linea", linea=error.linea)
    return f"{prefijo}\n    {contenido}\n{error.mensaje}"

USO = """uso: anlaco <comando> <archivo.ana>
       anlaco               (sin nada: sesión interactiva)

comandos:
  ejecutar   ejecuta el programa
  formatear  reescribe el programa en la forma canónica
  traducir   anlaco traducir archivo.ana --a en
  arbol      muestra el árbol del programa (la estructura que ve el intérprete)
  fichas     muestra las fichas del lexer (cómo se trocea cada línea)
  compilar   convierte el programa a WebAssembly (escribe archivo.wasm y .wat)
  repl       sesión interactiva (repl en = en inglés)
"""


def dibujar_arbol(nodo, sangria: str = ""):
    if isinstance(nodo, str):
        print(f'{sangria}literal {nodo!r}')
        return
    etiqueta = type(nodo).__name__
    simples = []
    hijos = []
    for campo in fields(nodo):
        if campo.name == "linea":
            continue
        valor = getattr(nodo, campo.name)
        if isinstance(valor, Nodo):
            hijos.append((campo.name, [valor]))
        elif isinstance(valor, list) and valor and all(isinstance(x, (Nodo, str)) for x in valor):
            hijos.append((campo.name, valor))
        else:
            simples.append(f"{campo.name}={valor!r}")
    detalle = (" " + " ".join(simples)) if simples else ""
    print(f"{sangria}{etiqueta}{detalle}")
    for nombre, valores in hijos:
        print(f"{sangria}  {nombre}:")
        for valor in valores:
            dibujar_arbol(valor, sangria + "    ")


def main(argv: list[str] | None = None) -> int:
    argumentos = sys.argv[1:] if argv is None else argv
    if not argumentos or argumentos[0] == "repl":
        from .repl import iniciar
        idioma = argumentos[1] if len(argumentos) > 1 else "es"
        try:
            iniciar(idioma)
        except KeyboardInterrupt:
            print()
        return 0
    if argumentos[0] == "traducir" and len(argumentos) >= 3:
        from .emisor import traducir
        ruta = argumentos[1]
        destino = argumentos[-1]  # admite "traducir f.ana --a en" y "traducir f.ana en"
        try:
            fuente = Path(ruta).read_text("utf-8")
            print(traducir(fuente, destino), end="")
        except FileNotFoundError:
            print(f"No encuentro el archivo {ruta}")
            return 1
        except ErrorDeAnlaco as error:
            print(presentar_error(error, fuente))
            return 1
        return 0
    if len(argumentos) != 2 or argumentos[0] not in ("ejecutar", "formatear", "arbol", "fichas", "compilar"):
        print(USO, end="")
        return 2
    comando, ruta = argumentos
    try:
        fuente = Path(ruta).read_text("utf-8")
    except FileNotFoundError:
        print(f"No encuentro el archivo {ruta}")
        return 1
    try:
        if comando == "ejecutar":
            idioma = detectar_idioma(fuente)
            Interprete(idioma=idioma).ejecutar(parse(fuente, idioma))
        elif comando == "formatear":
            from .emisor import formatear
            print(formatear(fuente), end="")
        elif comando == "compilar":
            from .compilador import compilar
            from .wat2wasm import ensamblar
            wat = compilar(fuente)
            wat_destino = Path(ruta).with_suffix(".wat")
            wasm_destino = Path(ruta).with_suffix(".wasm")
            wat_destino.write_text(wat, "utf-8")  # texto, para poder mirarlo
            wasm_destino.write_bytes(ensamblar(wat))
            print(f"He escrito {wasm_destino} (y {wat_destino})")
            print(f"Pruébalo con: wasmtime run --dir . -W function-references=y,gc=y {wasm_destino}")
        elif comando == "arbol":
            dibujar_arbol(parse(fuente))
        else:
            for ficha in tokenize(fuente):
                print(f"{ficha.line:4}  {ficha.type.name:12} {ficha.value!r}")
    except ErrorDeAnlaco as error:
        print(presentar_error(error, fuente))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
